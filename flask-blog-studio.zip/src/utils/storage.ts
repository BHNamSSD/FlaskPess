import { Post, User } from '../types';
import { INITIAL_POSTS } from '../data/initialPosts';

const POSTS_KEY = 'flask_blog_posts';
const THEME_KEY = 'flask_blog_theme';
const DRAFT_KEY = 'flask_blog_draft';
const USERS_KEY = 'flask_blog_users';
const CURRENT_USER_KEY = 'flask_blog_current_user';

export const ADMIN_MASTER_PIN = 'ADMIN-8888';

export const INITIAL_USERS: User[] = [
  {
    id: 'user-admin-1',
    username: 'admin',
    name: 'BHNam',
    email: 'phamhuynam.com@gmail.com',
    password: 'admin123@password',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    role: 'admin',
    bio: 'Quản trị viên hệ thống & Nhà phát triển chính FlaskPress SQLite',
    status: 'active',
    createdAt: '2026-01-10T08:00:00.000Z',
    lastLoginAt: '2026-08-24T03:00:00.000Z',
    isAdminVerified: true,
  },
  {
    id: 'user-2',
    username: 'halinh',
    name: 'Nguyễn Hà Linh',
    email: 'halinh.tech@example.com',
    password: 'user123@password',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80',
    role: 'user',
    bio: 'Lập trình viên Backend, yêu thích Python, Flask & Microservices',
    status: 'active',
    createdAt: '2026-02-15T10:30:00.000Z',
    lastLoginAt: '2026-08-22T14:10:00.000Z',
    isAdminVerified: false,
  },
  {
    id: 'user-3',
    username: 'duc_tran',
    name: 'Trần Minh Đức',
    email: 'duc.tran@example.com',
    password: 'user123@password',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
    role: 'user',
    bio: 'Frontend Developer & UI/UX Designer đam mê Markdown & Tailwind CSS',
    status: 'active',
    createdAt: '2026-03-01T14:20:00.000Z',
    lastLoginAt: '2026-08-20T09:45:00.000Z',
    isAdminVerified: false,
  },
  {
    id: 'user-4',
    username: 'baole',
    name: 'Lê Quốc Bảo',
    email: 'bao.le@example.com',
    password: 'user123@password',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80',
    role: 'user',
    bio: 'Tài khoản vi phạm chính sách cộng đồng (Spam quảng cáo)',
    status: 'banned',
    createdAt: '2026-04-12T09:15:00.000Z',
    lastLoginAt: '2026-05-01T11:00:00.000Z',
    isAdminVerified: false,
  },
];

export function getStoredUsers(): User[] {
  try {
    const raw = localStorage.getItem(USERS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.error('Error reading users from localStorage:', err);
  }
  saveStoredUsers(INITIAL_USERS);
  return INITIAL_USERS;
}

export function saveStoredUsers(users: User[]): void {
  try {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  } catch (err) {
    console.error('Error saving users to localStorage:', err);
  }
}

export function getStoredCurrentUser(): User {
  try {
    const raw = localStorage.getItem(CURRENT_USER_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.id) {
        return parsed;
      }
    }
  } catch (err) {
    console.error('Error reading current user from localStorage:', err);
  }
  const defaultAdmin = INITIAL_USERS[0];
  saveStoredCurrentUser(defaultAdmin);
  return defaultAdmin;
}

export function saveStoredCurrentUser(user: User): void {
  try {
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
  } catch (err) {
    console.error('Error saving current user to localStorage:', err);
  }
}


export function getStoredPosts(): Post[] {
  try {
    const raw = localStorage.getItem(POSTS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.error('Error reading posts from localStorage:', err);
  }
  // Initialize with default posts
  saveStoredPosts(INITIAL_POSTS);
  return INITIAL_POSTS;
}

export function saveStoredPosts(posts: Post[]): void {
  try {
    localStorage.setItem(POSTS_KEY, JSON.stringify(posts));
  } catch (err) {
    console.error('Error saving posts to localStorage:', err);
  }
}

export function getStoredTheme(): 'light' | 'dark' {
  try {
    const saved = localStorage.getItem(THEME_KEY);
    if (saved === 'light' || saved === 'dark') {
      return saved;
    }
    // Check system preference
    if (typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      return 'dark';
    }
  } catch (err) {
    console.error('Error reading theme:', err);
  }
  return 'light';
}

export function saveStoredTheme(theme: 'light' | 'dark'): void {
  try {
    localStorage.setItem(THEME_KEY, theme);
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  } catch (err) {
    console.error('Error saving theme:', err);
  }
}

export interface DraftPost {
  title: string;
  category: string;
  tags: string;
  coverImage: string;
  excerpt: string;
  content: string;
  authorName: string;
}

export function getStoredDraft(): DraftPost | null {
  try {
    const raw = localStorage.getItem(DRAFT_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Error reading draft:', e);
  }
  return null;
}

export function saveStoredDraft(draft: DraftPost): void {
  try {
    localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
  } catch (e) {
    console.error('Error saving draft:', e);
  }
}

export function clearStoredDraft(): void {
  try {
    localStorage.removeItem(DRAFT_KEY);
  } catch (e) {
    console.error('Error clearing draft:', e);
  }
}
