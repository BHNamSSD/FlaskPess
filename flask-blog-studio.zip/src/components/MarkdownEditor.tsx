import React, { useState, useEffect, useRef } from 'react';
import { Post, CurrentView } from '../types';
import { renderMarkdown, getWordAndCharCount, calculateReadingTime, generateSlug } from '../utils/markdown';
import { getStoredDraft, saveStoredDraft, clearStoredDraft } from '../utils/storage';
import { AVAILABLE_CATEGORIES } from '../data/initialPosts';
import { 
  Bold, 
  Italic, 
  Strikethrough, 
  Heading1, 
  Heading2, 
  Heading3, 
  Quote, 
  Code, 
  FileCode, 
  List, 
  ListOrdered, 
  CheckSquare, 
  Table, 
  Link, 
  Image, 
  Minus, 
  Eye, 
  Columns, 
  Edit3, 
  Save, 
  ArrowLeft, 
  Sparkles, 
  Image as ImageIcon,
  HelpCircle,
  Clock,
  FileText
} from 'lucide-react';

interface MarkdownEditorProps {
  postToEdit?: Post | null;
  onSave: (postData: Partial<Post>) => void;
  onCancel: () => void;
  showToast: (msg: string, type?: 'success' | 'info' | 'error') => void;
}

export const MarkdownEditor: React.FC<MarkdownEditorProps> = ({
  postToEdit,
  onSave,
  onCancel,
  showToast,
}) => {
  const isEditing = !!postToEdit;

  const [title, setTitle] = useState(postToEdit?.title || '');
  const [slug, setSlug] = useState(postToEdit?.slug || '');
  const [category, setCategory] = useState(postToEdit?.category || 'Lập trình Python');
  const [tagsInput, setTagsInput] = useState(postToEdit?.tags?.join(', ') || '');
  const [coverImage, setCoverImage] = useState(postToEdit?.coverImage || '');
  const [authorName, setAuthorName] = useState(postToEdit?.author?.name || 'Nguyễn Văn Nam');
  const [excerpt, setExcerpt] = useState(postToEdit?.excerpt || '');
  const [content, setContent] = useState(postToEdit?.content || '');
  
  // Editor view mode: 'split' | 'edit' | 'preview'
  const [editorMode, setEditorMode] = useState<'split' | 'edit' | 'preview'>('split');
  const [lastSavedTime, setLastSavedTime] = useState<string>('');

  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Restore draft if creating a new post and draft exists
  useEffect(() => {
    if (!isEditing) {
      const draft = getStoredDraft();
      if (draft && draft.content) {
        setTitle(draft.title || '');
        setCategory(draft.category || 'Lập trình Python');
        setTagsInput(draft.tags || '');
        setCoverImage(draft.coverImage || '');
        setExcerpt(draft.excerpt || '');
        setContent(draft.content || '');
        setAuthorName(draft.authorName || 'BHNam');
        showToast('Đã khôi phục bản nháp chưa lưu!', 'info');
      }
    }
  }, [isEditing]);

  // Auto-save draft every 5 seconds for new post
  useEffect(() => {
    if (isEditing) return;

    const timer = setTimeout(() => {
      if (title.trim() || content.trim()) {
        saveStoredDraft({
          title,
          category,
          tags: tagsInput,
          coverImage,
          excerpt,
          content,
          authorName,
        });
        setLastSavedTime(new Date().toLocaleTimeString('vi-VN'));
      }
    }, 2000);

    return () => clearTimeout(timer);
  }, [title, category, tagsInput, coverImage, excerpt, content, authorName, isEditing]);

  // Auto-generate slug when title changes
  const handleTitleChange = (newTitle: string) => {
    setTitle(newTitle);
    if (!isEditing) {
      setSlug(generateSlug(newTitle));
    }
  };

  // Helper to insert markdown tags at cursor position
  const insertMarkdown = (prefix: string, suffix: string = '', defaultPlaceholder: string = '') => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = textarea.value.substring(start, end);
    const textToInsert = selectedText || defaultPlaceholder;

    const replacement = `${prefix}${textToInsert}${suffix}`;
    const newContent = 
      textarea.value.substring(0, start) + 
      replacement + 
      textarea.value.substring(end);

    setContent(newContent);

    // Reset cursor
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(
        start + prefix.length,
        start + prefix.length + textToInsert.length
      );
    }, 10);
  };

  // Auto-generate excerpt from content
  const handleAutoGenerateExcerpt = () => {
    if (!content.trim()) {
      showToast('Hãy viết nội dung trước khi tạo tóm tắt!', 'error');
      return;
    }
    const clean = content
      .replace(/^#+\s+/gm, '')
      .replace(/[*_`~[\]]/g, '')
      .replace(/\n+/g, ' ')
      .trim();
    const generated = clean.length > 160 ? clean.substring(0, 160) + '...' : clean;
    setExcerpt(generated);
    showToast('Đã tạo tóm tắt từ nội dung bài viết!', 'success');
  };

  // Quick preset cover image
  const setRandomCover = (presetUrl: string) => {
    setCoverImage(presetUrl);
  };

  const stats = getWordAndCharCount(content);
  const readingTime = calculateReadingTime(content);
  const renderedHtml = renderMarkdown(content);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!title.trim()) {
      showToast('Vui lòng nhập tiêu đề bài viết!', 'error');
      return;
    }
    if (!content.trim()) {
      showToast('Vui lòng nhập nội dung bài viết!', 'error');
      return;
    }

    const tagsArray = tagsInput
      .split(',')
      .map((t) => t.trim())
      .filter((t) => t.length > 0);

    const autoExcerpt = excerpt.trim() 
      ? excerpt.trim() 
      : content.replace(/^#+\s+/gm, '').replace(/[*_`~[\]]/g, '').trim().substring(0, 150) + '...';

    onSave({
      title: title.trim(),
      slug: slug || generateSlug(title),
      category: category.trim() || 'Chung',
      tags: tagsArray,
      coverImage: coverImage.trim() || undefined,
      excerpt: autoExcerpt,
      content: content.trim(),
      author: {
        name: authorName.trim() || 'Admin',
        avatar: postToEdit?.author?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
        role: postToEdit?.author?.role || 'Tác giả',
      },
      readingTimeMinutes: readingTime,
    });

    if (!isEditing) {
      clearStoredDraft();
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={onCancel}
            className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
            title="Quay lại"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              {isEditing ? 'Chỉnh sửa bài viết' : 'Đăng bài viết mới'}
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Hỗ trợ định dạng Markdown với xem trước thời gian thực
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {!isEditing && lastSavedTime && (
            <span className="text-xs text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-500/20 px-2.5 py-1 rounded-full font-medium hidden sm:inline-block">
              ✓ Đã lưu nháp lúc {lastSavedTime}
            </span>
          )}

          <button
            onClick={onCancel}
            className="px-4 py-2 text-sm font-semibold rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            Hủy
          </button>

          <button
            onClick={handleSubmit}
            id="btn-publish-post"
            className="flex items-center gap-2 px-5 py-2 text-sm font-bold rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-500/20 transition-all hover:scale-105 active:scale-95"
          >
            <Save className="w-4 h-4" />
            {isEditing ? 'Lưu thay đổi' : 'Xuất bản bài viết'}
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        
        {/* Title & Slug */}
        <div className="bg-white dark:bg-slate-900/70 p-5 sm:p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
              Tiêu đề bài viết <span className="text-rose-500">*</span>
            </label>
            <input
              id="editor-title-input"
              type="text"
              value={title}
              onChange={(e) => handleTitleChange(e.target.value)}
              placeholder="Nhập tiêu đề bài viết ấn tượng..."
              className="w-full text-lg sm:text-xl font-bold px-4 py-3 bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none text-slate-900 dark:text-white"
              required
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Category */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                Chuyên mục
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full text-sm px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none text-slate-900 dark:text-white"
              >
                {AVAILABLE_CATEGORIES.filter((c) => c !== 'Tất cả').map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            {/* Tags */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                Thẻ Tags (cách nhau bởi dấu phẩy)
              </label>
              <input
                type="text"
                value={tagsInput}
                onChange={(e) => setTagsInput(e.target.value)}
                placeholder="Python, Flask, SQLite, Markdown..."
                className="w-full text-sm px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none text-slate-900 dark:text-white"
              />
            </div>

            {/* Author */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                Tên tác giả
              </label>
              <input
                type="text"
                value={authorName}
                onChange={(e) => setAuthorName(e.target.value)}
                placeholder="Tên tác giả"
                className="w-full text-sm px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none text-slate-900 dark:text-white"
              />
            </div>
          </div>

          {/* Cover Image URL */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
              URL Ảnh bìa (Cover Image)
            </label>
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="url"
                value={coverImage}
                onChange={(e) => setCoverImage(e.target.value)}
                placeholder="https://images.unsplash.com/photo-..."
                className="flex-1 text-sm px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none text-slate-900 dark:text-white font-mono text-xs"
              />
              <div className="flex gap-1.5 overflow-x-auto py-1">
                <button
                  type="button"
                  onClick={() => setRandomCover('https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=1200&q=80')}
                  className="px-2.5 py-1 text-xs rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 whitespace-nowrap"
                >
                  Code
                </button>
                <button
                  type="button"
                  onClick={() => setRandomCover('https://images.unsplash.com/photo-1455390582262-044cdead277a?auto=format&fit=crop&w=1200&q=80')}
                  className="px-2.5 py-1 text-xs rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 whitespace-nowrap"
                >
                  Viết lách
                </button>
                <button
                  type="button"
                  onClick={() => setRandomCover('https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=1200&q=80')}
                  className="px-2.5 py-1 text-xs rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 whitespace-nowrap"
                >
                  Dark UI
                </button>
                {coverImage && (
                  <button
                    type="button"
                    onClick={() => setCoverImage('')}
                    className="px-2.5 py-1 text-xs rounded-lg text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/50"
                  >
                    Xóa ảnh
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Excerpt */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Tóm tắt ngắn (Excerpt)
              </label>
              <button
                type="button"
                onClick={handleAutoGenerateExcerpt}
                className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1 font-medium"
              >
                <Sparkles className="w-3.5 h-3.5" />
                Tự động tạo từ nội dung
              </button>
            </div>
            <textarea
              value={excerpt}
              onChange={(e) => setExcerpt(e.target.value)}
              placeholder="Tóm tắt ngắn hiển thị ở danh sách bài viết trang chủ..."
              rows={2}
              className="w-full text-sm px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none text-slate-900 dark:text-white"
            />
          </div>
        </div>

        {/* Markdown Toolbar & Content Area */}
        <div className="bg-white dark:bg-slate-900/70 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden">
          
          {/* Top Toolbar */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
            
            {/* Formatting Tools */}
            <div className="flex flex-wrap items-center gap-1">
              <button
                type="button"
                onClick={() => insertMarkdown('**', '**', 'văn bản đậm')}
                className="p-1.5 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 font-bold"
                title="Chữ đậm (Bold - **text**)"
              >
                <Bold className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => insertMarkdown('*', '*', 'văn bản nghiêng')}
                className="p-1.5 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 italic"
                title="Chữ nghiêng (Italic - *text*)"
              >
                <Italic className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => insertMarkdown('~~', '~~', 'văn bản gạch ngang')}
                className="p-1.5 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
                title="Gạch ngang (~~text~~)"
              >
                <Strikethrough className="w-4 h-4" />
              </button>

              <span className="h-4 w-px bg-slate-300 dark:bg-slate-700 mx-1" />

              <button
                type="button"
                onClick={() => insertMarkdown('# ', '', 'Tiêu đề cấp 1')}
                className="p-1.5 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 font-bold text-xs"
                title="Tiêu đề H1 (# Tiêu đề)"
              >
                <Heading1 className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => insertMarkdown('## ', '', 'Tiêu đề cấp 2')}
                className="p-1.5 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 font-bold text-xs"
                title="Tiêu đề H2 (## Tiêu đề)"
              >
                <Heading2 className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => insertMarkdown('### ', '', 'Tiêu đề cấp 3')}
                className="p-1.5 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 font-bold text-xs"
                title="Tiêu đề H3 (### Tiêu đề)"
              >
                <Heading3 className="w-4 h-4" />
              </button>

              <span className="h-4 w-px bg-slate-300 dark:bg-slate-700 mx-1" />

              <button
                type="button"
                onClick={() => insertMarkdown('> ', '', 'Trích dẫn quan trọng...')}
                className="p-1.5 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
                title="Khối trích dẫn (> Trích dẫn)"
              >
                <Quote className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => insertMarkdown('`', '`', 'code')}
                className="p-1.5 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 font-mono text-xs"
                title="Mã nội dòng (`code`)"
              >
                <Code className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => insertMarkdown('```python\n', '\n```', '# Viết mã nguồn Python tại đây\nprint("Hello, Flask!")')}
                className="p-1.5 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
                title="Khối mã nguồn (```code```)"
              >
                <FileCode className="w-4 h-4" />
              </button>

              <span className="h-4 w-px bg-slate-300 dark:bg-slate-700 mx-1" />

              <button
                type="button"
                onClick={() => insertMarkdown('- ', '', 'Mục danh sách')}
                className="p-1.5 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
                title="Danh sách gạch đầu dòng (- )"
              >
                <List className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => insertMarkdown('1. ', '', 'Mục thứ tự')}
                className="p-1.5 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
                title="Danh sách đánh số (1. )"
              >
                <ListOrdered className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => insertMarkdown('- [ ] ', '', 'Công việc cần làm')}
                className="p-1.5 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
                title="Danh sách công việc (- [ ] )"
              >
                <CheckSquare className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => insertMarkdown('\n| Cột 1 | Cột 2 | Cột 3 |\n| :--- | :--- | :--- |\n| Dữ liệu 1 | Dữ liệu 2 | Dữ liệu 3 |\n')}
                className="p-1.5 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
                title="Chèn bảng (Table)"
              >
                <Table className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => insertMarkdown('[', '](https://example.com)', 'Tiêu đề liên kết')}
                className="p-1.5 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
                title="Chèn liên kết ([tên](url))"
              >
                <Link className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => insertMarkdown('![', '](https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800)', 'Mô tả hình ảnh')}
                className="p-1.5 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
                title="Chèn hình ảnh (![alt](url))"
              >
                <Image className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => insertMarkdown('\n---\n')}
                className="p-1.5 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
                title="Đường kẻ phân cách (---)"
              >
                <Minus className="w-4 h-4" />
              </button>
            </div>

            {/* View Mode Switchers */}
            <div className="flex items-center gap-1 bg-slate-200 dark:bg-slate-800 p-1 rounded-lg border border-slate-300/50 dark:border-slate-700/50">
              <button
                type="button"
                onClick={() => setEditorMode('edit')}
                className={`px-2.5 py-1 text-xs rounded-md font-medium transition-colors ${
                  editorMode === 'edit'
                    ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
                title="Chỉ soạn thảo"
              >
                <Edit3 className="w-3.5 h-3.5 inline mr-1" />
                Soạn thảo
              </button>
              <button
                type="button"
                onClick={() => setEditorMode('split')}
                className={`px-2.5 py-1 text-xs rounded-md font-medium transition-colors hidden md:inline-flex items-center ${
                  editorMode === 'split'
                    ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
                title="Chia đôi màn hình"
              >
                <Columns className="w-3.5 h-3.5 inline mr-1" />
                Chia đôi
              </button>
              <button
                type="button"
                onClick={() => setEditorMode('preview')}
                className={`px-2.5 py-1 text-xs rounded-md font-medium transition-colors ${
                  editorMode === 'preview'
                    ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
                title="Xem trước"
              >
                <Eye className="w-3.5 h-3.5 inline mr-1" />
                Xem trước
              </button>
            </div>
          </div>

          {/* Editor & Preview Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-slate-200 dark:divide-slate-800 min-h-[480px]">
            
            {/* Editor Area */}
            {(editorMode === 'edit' || editorMode === 'split') && (
              <div className={`p-4 ${editorMode === 'edit' ? 'col-span-2' : ''} flex flex-col`}>
                <textarea
                  id="editor-content-textarea"
                  ref={textareaRef}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="# Nhập tiêu đề bài viết tại đây...&#10;&#10;Bắt đầu viết nội dung định dạng Markdown tuyệt vời của bạn tại đây!&#10;&#10;- Có thể sử dụng bảng biểu&#10;- Khối mã code ```python ... ```&#10;- Trích dẫn > ..."
                  className="w-full flex-1 min-h-[420px] p-2 bg-transparent text-slate-900 dark:text-slate-100 font-mono text-sm leading-relaxed resize-none focus:outline-none"
                  required
                />
              </div>
            )}

            {/* Live Preview Area */}
            {(editorMode === 'preview' || editorMode === 'split') && (
              <div className={`p-6 overflow-y-auto max-h-[600px] bg-slate-50/50 dark:bg-slate-950/40 ${editorMode === 'preview' ? 'col-span-2' : ''}`}>
                <div className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-3 pb-2 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <span>Xem trước trực tiếp (Live Markdown Preview)</span>
                  <span className="text-indigo-600 dark:text-indigo-400 font-normal">Tự động cập nhật</span>
                </div>
                {content.trim() ? (
                  <div
                    className="markdown-body"
                    dangerouslySetInnerHTML={{ __html: renderedHtml }}
                  />
                ) : (
                  <div className="text-center py-16 text-slate-400 dark:text-slate-500 text-sm">
                    <FileText className="w-10 h-10 mx-auto mb-2 opacity-40" />
                    <p>Bản xem trước bài viết của bạn sẽ hiển thị tại đây khi bạn nhập nội dung.</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Editor Status Footer */}
          <div className="px-4 py-2.5 bg-slate-100/70 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-500 dark:text-slate-400">
            <div className="flex items-center gap-4">
              <span><strong>{stats.words}</strong> từ</span>
              <span><strong>{stats.chars}</strong> ký tự</span>
              <span><strong>{stats.lines}</strong> dòng</span>
            </div>
            <div className="flex items-center gap-1.5 font-medium">
              <Clock className="w-3.5 h-3.5 text-indigo-500" />
              <span>Ước tính thời gian đọc: <strong>{readingTime} phút</strong></span>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};
