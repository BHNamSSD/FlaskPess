import React, { useState } from 'react';
import { User, UserRole } from '../types';
import { ADMIN_MASTER_PIN } from '../utils/storage';
import { 
  Users, 
  Crown, 
  ShieldCheck, 
  UserCheck, 
  LogIn, 
  UserPlus,
  Check, 
  X, 
  Sparkles, 
  KeyRound,
  Lock,
  Mail,
  User as UserIcon,
  Shield,
  HelpCircle,
  Code2,
  AlertTriangle,
  ArrowRight,
  Eye,
  EyeOff
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  users: User[];
  currentUser: User;
  onLogin: (user: User) => void;
  onRegister: (newUser: Omit<User, 'id' | 'createdAt' | 'lastLoginAt'>) => void;
  showToast: (text: string, type?: 'success' | 'error' | 'info') => void;
  initialTab?: 'login' | 'register' | 'switch' | 'verify-admin';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  users,
  currentUser,
  onLogin,
  onRegister,
  showToast,
  initialTab = 'login',
}) => {
  const [activeTab, setActiveTab] = useState<'login' | 'register' | 'switch' | 'verify-admin'>(initialTab);

  // Login form state
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginAdminPin, setLoginAdminPin] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [requiresAdminPin, setRequiresAdminPin] = useState(false);

  // Register form state
  const [regName, setRegName] = useState('');
  const [regUsername, setRegUsername] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regIsAdmin, setRegIsAdmin] = useState(false);
  const [regAdminPin, setRegAdminPin] = useState('');

  // Admin Verification for Current User
  const [verifyPinInput, setVerifyPinInput] = useState('');

  if (!isOpen) return null;

  // Handle Quick Switch
  const handleFastSwitch = (user: User) => {
    if (user.status === 'banned') {
      showToast(`Tài khoản "${user.name}" đang bị khóa do vi phạm chính sách!`, 'error');
      return;
    }
    onLogin(user);
    showToast(`Đã đăng nhập: ${user.name} (${user.role === 'admin' ? '👑 Quản trị viên' : '👤 Người dùng'})`, 'success');
    onClose();
  };

  // Handle Login Submit
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const ident = loginIdentifier.trim().toLowerCase();
    if (!ident) {
      showToast('Vui lòng nhập Email hoặc Tên đăng nhập!', 'error');
      return;
    }

    const foundUser = users.find(
      (u) => u.username.toLowerCase() === ident || u.email.toLowerCase() === ident
    );

    if (!foundUser) {
      showToast('Tài khoản không tồn tại trong hệ thống! Hãy thử đăng ký mới.', 'error');
      return;
    }

    if (foundUser.status === 'banned') {
      showToast('Tài khoản này đã bị khóa do vi phạm quy định!', 'error');
      return;
    }

    // Check if user is Admin and requires PIN verification
    if (foundUser.role === 'admin') {
      if (!requiresAdminPin) {
        setRequiresAdminPin(true);
        showToast('Tài khoản Quản trị viên cần nhập Mã xác minh Admin (Master PIN)!', 'info');
        return;
      }

      if (loginAdminPin.trim() !== ADMIN_MASTER_PIN) {
        showToast(`Mã xác minh Admin không chính xác! (Mã mặc định: ${ADMIN_MASTER_PIN})`, 'error');
        return;
      }
    }

    onLogin(foundUser);
    showToast(`Đăng nhập thành công! Chào mừng ${foundUser.name} (${foundUser.role === 'admin' ? '👑 Admin' : '👤 Thành viên'}).`, 'success');
    onClose();
  };

  // Handle Register Submit
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName.trim() || !regUsername.trim() || !regEmail.trim() || !regPassword.trim()) {
      showToast('Vui lòng điền đầy đủ các thông tin đăng ký!', 'error');
      return;
    }

    const usernameClean = regUsername.trim().toLowerCase().replace(/\s+/g, '_');
    const existing = users.find(
      (u) => u.username.toLowerCase() === usernameClean || u.email.toLowerCase() === regEmail.trim().toLowerCase()
    );

    if (existing) {
      showToast('Tên đăng nhập hoặc Email này đã được sử dụng!', 'error');
      return;
    }

    let role: UserRole = 'user';
    let isAdminVerified = false;

    if (regIsAdmin) {
      if (regAdminPin.trim() !== ADMIN_MASTER_PIN) {
        showToast(`Mã kích hoạt Quản trị viên không đúng! (Mã mẫu: ${ADMIN_MASTER_PIN})`, 'error');
        return;
      }
      role = 'admin';
      isAdminVerified = true;
    }

    const avatar = `https://api.dicebear.com/7.x/notionists/svg?seed=${encodeURIComponent(usernameClean)}`;

    onRegister({
      name: regName.trim(),
      username: usernameClean,
      email: regEmail.trim().toLowerCase(),
      password: regPassword,
      role,
      status: 'active',
      avatar,
      bio: role === 'admin' ? 'Quản trị viên hệ thống Blog' : 'Thành viên cộng đồng Flask Blog',
      isAdminVerified,
    });

    showToast(`Đăng ký thành công! Đã đăng nhập tự động với vai trò ${role === 'admin' ? '👑 Quản trị viên' : '👤 Người dùng'}.`, 'success');
    onClose();
  };

  // Quick fill credentials
  const fillQuickCredentials = (username: string, role: 'admin' | 'user') => {
    setLoginIdentifier(username);
    setLoginPassword('password123');
    if (role === 'admin') {
      setRequiresAdminPin(true);
      setLoginAdminPin(ADMIN_MASTER_PIN);
    } else {
      setRequiresAdminPin(false);
      setLoginAdminPin('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs animate-in fade-in overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl space-y-5 my-8">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600/10 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold shadow-inner">
              <KeyRound className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                Xác thực & Quản trị tài khoản
              </h3>
              <p className="text-xs text-slate-400">
                Đăng nhập, phân quyền RBAC và cơ chế bảo mật Admin
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="grid grid-cols-4 gap-1 bg-slate-100 dark:bg-slate-800/80 p-1 rounded-2xl text-[11px] sm:text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab('login')}
            className={`py-2 px-1 rounded-xl transition-all flex items-center justify-center gap-1 ${
              activeTab === 'login'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs font-bold'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-300'
            }`}
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>Đăng nhập</span>
          </button>
          
          <button
            type="button"
            onClick={() => setActiveTab('register')}
            className={`py-2 px-1 rounded-xl transition-all flex items-center justify-center gap-1 ${
              activeTab === 'register'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs font-bold'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-300'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Đăng ký</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('switch')}
            className={`py-2 px-1 rounded-xl transition-all flex items-center justify-center gap-1 ${
              activeTab === 'switch'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs font-bold'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-300'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Tài khoản mẫu</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('verify-admin')}
            className={`py-2 px-1 rounded-xl transition-all flex items-center justify-center gap-1 ${
              activeTab === 'verify-admin'
                ? 'bg-white dark:bg-slate-900 text-amber-600 dark:text-amber-400 shadow-xs font-bold'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-300'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-amber-500" />
            <span>Xác minh Admin</span>
          </button>
        </div>

        {/* TAB 1: LOGIN */}
        {activeTab === 'login' && (
          <form onSubmit={handleLoginSubmit} className="space-y-4">
            {/* Quick Demo Fillers */}
            <div className="p-3 bg-slate-50 dark:bg-slate-950/50 rounded-2xl border border-slate-200/70 dark:border-slate-800 space-y-2">
              <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider flex items-center justify-between">
                <span>⚡ Điền nhanh tài khoản thử nghiệm:</span>
              </div>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => fillQuickCredentials('admin', 'admin')}
                  className="px-2.5 py-1 text-xs rounded-lg bg-amber-500/10 text-amber-700 dark:text-amber-300 border border-amber-500/30 hover:bg-amber-500/20 font-semibold flex items-center gap-1 transition-colors"
                >
                  <span>👑 Admin (BHNam)</span>
                </button>
                <button
                  type="button"
                  onClick={() => fillQuickCredentials('halinh', 'user')}
                  className="px-2.5 py-1 text-xs rounded-lg bg-indigo-500/10 text-indigo-700 dark:text-indigo-300 border border-indigo-500/30 hover:bg-indigo-500/20 font-semibold flex items-center gap-1 transition-colors"
                >
                  <span>👤 User (Hà Linh)</span>
                </button>
                <button
                  type="button"
                  onClick={() => fillQuickCredentials('duc_tran', 'user')}
                  className="px-2.5 py-1 text-xs rounded-lg bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-300 font-semibold text-xs flex items-center gap-1 transition-colors"
                >
                  <span>👤 User (Minh Đức)</span>
                </button>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Email hoặc Tên đăng nhập
                </label>
                <div className="relative">
                  <UserIcon className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    value={loginIdentifier}
                    onChange={(e) => setLoginIdentifier(e.target.value)}
                    placeholder="Nhập admin, halinh hoặc email..."
                    className="w-full pl-10 pr-4 py-2.5 text-sm bg-slate-50 dark:bg-slate-950/70 rounded-xl border border-slate-200 dark:border-slate-800 focus:ring-2 focus:ring-indigo-500 focus:outline-none text-slate-900 dark:text-white"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Mật khẩu
                </label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="Nhập mật khẩu của bạn..."
                    className="w-full pl-10 pr-10 py-2.5 text-sm bg-slate-50 dark:bg-slate-950/70 rounded-xl border border-slate-200 dark:border-slate-800 focus:ring-2 focus:ring-indigo-500 focus:outline-none text-slate-900 dark:text-white"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Admin Master PIN Verification */}
              {requiresAdminPin && (
                <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/40 space-y-2 animate-in fade-in slide-in-from-top-1">
                  <div className="flex items-center gap-2 text-xs font-bold text-amber-800 dark:text-amber-300">
                    <ShieldCheck className="w-4 h-4 text-amber-500" />
                    <span>Xác minh quyền Quản trị viên (Master PIN)</span>
                  </div>
                  <p className="text-[11px] text-amber-700/90 dark:text-amber-400/90">
                    Tài khoản này có vai trò Admin. Vui lòng nhập mã xác minh bảo mật (Mã mặc định: <code className="font-mono font-bold bg-amber-500/20 px-1 py-0.5 rounded">{ADMIN_MASTER_PIN}</code>):
                  </p>
                  <div className="relative">
                    <KeyRound className="absolute left-3 top-2.5 w-4 h-4 text-amber-500" />
                    <input
                      type="text"
                      value={loginAdminPin}
                      onChange={(e) => setLoginAdminPin(e.target.value)}
                      placeholder={`Nhập ${ADMIN_MASTER_PIN}...`}
                      className="w-full pl-9 pr-3 py-2 text-xs font-mono font-bold bg-white dark:bg-slate-900 border border-amber-400 dark:border-amber-600 rounded-xl text-amber-900 dark:text-amber-200 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                    />
                  </div>
                </div>
              )}
            </div>

            <button
              type="submit"
              className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm rounded-xl shadow-lg shadow-indigo-500/20 transition-all flex items-center justify-center gap-2 hover:scale-[1.01] active:scale-[0.99]"
            >
              <LogIn className="w-4 h-4" />
              <span>Đăng nhập hệ thống</span>
            </button>
          </form>
        )}

        {/* TAB 2: REGISTER */}
        {activeTab === 'register' && (
          <form onSubmit={handleRegisterSubmit} className="space-y-3.5">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Họ và tên hiển thị
              </label>
              <input
                type="text"
                value={regName}
                onChange={(e) => setRegName(e.target.value)}
                placeholder="VD: Lê Hoàng Nam"
                className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950/70 rounded-xl border border-slate-200 dark:border-slate-800 focus:ring-2 focus:ring-indigo-500 focus:outline-none text-slate-900 dark:text-white"
                required
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Tên đăng nhập
                </label>
                <input
                  type="text"
                  value={regUsername}
                  onChange={(e) => setRegUsername(e.target.value)}
                  placeholder="nam_le"
                  className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950/70 rounded-xl border border-slate-200 dark:border-slate-800 focus:ring-2 focus:ring-indigo-500 focus:outline-none text-slate-900 dark:text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                  placeholder="nam@example.com"
                  className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950/70 rounded-xl border border-slate-200 dark:border-slate-800 focus:ring-2 focus:ring-indigo-500 focus:outline-none text-slate-900 dark:text-white"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Mật khẩu
              </label>
              <input
                type="password"
                value={regPassword}
                onChange={(e) => setRegPassword(e.target.value)}
                placeholder="Tối thiểu 6 ký tự..."
                className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-950/70 rounded-xl border border-slate-200 dark:border-slate-800 focus:ring-2 focus:ring-indigo-500 focus:outline-none text-slate-900 dark:text-white"
                required
              />
            </div>

            {/* Admin Role Registration Checkbox */}
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-950/50 border border-slate-200 dark:border-slate-800 space-y-2.5">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={regIsAdmin}
                  onChange={(e) => setRegIsAdmin(e.target.checked)}
                  className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500"
                />
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1">
                  👑 Đăng ký với tư cách Quản trị viên (Admin)
                </span>
              </label>

              {regIsAdmin && (
                <div className="pt-2 border-t border-slate-200 dark:border-slate-800 space-y-1.5 animate-in fade-in">
                  <div className="text-[11px] text-amber-600 dark:text-amber-400 font-semibold">
                    Yêu cầu mã xác minh Admin Master PIN:
                  </div>
                  <input
                    type="text"
                    value={regAdminPin}
                    onChange={(e) => setRegAdminPin(e.target.value)}
                    placeholder={`Nhập ${ADMIN_MASTER_PIN}...`}
                    className="w-full px-3 py-1.5 text-xs font-mono font-bold bg-white dark:bg-slate-900 border border-amber-400 rounded-xl focus:ring-2 focus:ring-amber-500 text-amber-900 dark:text-amber-200 focus:outline-none"
                    required
                  />
                </div>
              )}
            </div>

            <button
              type="submit"
              className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm rounded-xl shadow-lg shadow-indigo-500/20 transition-all flex items-center justify-center gap-2 hover:scale-[1.01] active:scale-[0.99]"
            >
              <UserPlus className="w-4 h-4" />
              <span>Tạo tài khoản & Đăng nhập</span>
            </button>
          </form>
        )}

        {/* TAB 3: FAST SWITCHER */}
        {activeTab === 'switch' && (
          <div className="space-y-3">
            <div className="text-xs text-slate-500 dark:text-slate-400">
              Nhấp vào bất kỳ tài khoản nào để chuyển phiên làm việc ngay lập tức:
            </div>

            <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
              {users.map((user) => {
                const isSelected = user.id === currentUser.id;
                const isBanned = user.status === 'banned';

                return (
                  <div
                    key={user.id}
                    onClick={() => handleFastSwitch(user)}
                    className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                      isSelected
                        ? 'bg-indigo-50/60 dark:bg-indigo-950/40 border-indigo-500/50 shadow-xs'
                        : isBanned
                        ? 'bg-slate-50 dark:bg-slate-950/40 border-slate-200 dark:border-slate-800 opacity-60'
                        : 'bg-slate-50/50 dark:bg-slate-950/60 border-slate-200/80 dark:border-slate-800 hover:border-indigo-400/60 dark:hover:border-indigo-500/60'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="relative flex-shrink-0">
                        <img
                          src={user.avatar}
                          alt={user.name}
                          className="w-10 h-10 rounded-full object-cover border border-slate-200 dark:border-slate-700"
                          referrerPolicy="no-referrer"
                        />
                        {user.role === 'admin' && (
                          <span className="absolute -top-1 -right-1 w-4 h-4 bg-amber-500 text-slate-950 rounded-full flex items-center justify-center text-[9px] font-bold">
                            👑
                          </span>
                        )}
                      </div>

                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-slate-900 dark:text-white truncate">
                            {user.name}
                          </span>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border uppercase ${
                            user.role === 'admin'
                              ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30'
                              : 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border-indigo-500/30'
                          }`}>
                            {user.role === 'admin' ? '👑 Admin' : '👤 User'}
                          </span>
                        </div>
                        <div className="text-xs text-slate-400 font-mono truncate">
                          @{user.username} • {user.email}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 flex-shrink-0">
                      {isBanned && (
                        <span className="text-[11px] font-bold text-rose-500 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20">
                          Bị khóa
                        </span>
                      )}
                      {isSelected ? (
                        <div className="w-7 h-7 rounded-full bg-indigo-600 text-white flex items-center justify-center">
                          <Check className="w-4 h-4" />
                        </div>
                      ) : (
                        <button
                          type="button"
                          className="px-3 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-semibold hover:bg-indigo-600 hover:text-white transition-colors"
                        >
                          Chọn
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 4: ADMIN VERIFICATION & ARCHITECTURE */}
        {activeTab === 'verify-admin' && (
          <div className="space-y-3.5 text-xs">
            {/* Direct PIN Verification box */}
            <div className="p-4 bg-amber-500/10 dark:bg-amber-950/30 border border-amber-500/30 rounded-2xl space-y-2.5">
              <div className="flex items-center gap-2">
                <Crown className="w-5 h-5 text-amber-500" />
                <span className="font-bold text-amber-900 dark:text-amber-300 text-sm">
                  Cơ chế Xác minh Quyền Quản trị viên (Admin Verification)
                </span>
              </div>
              <p className="text-amber-800/90 dark:text-amber-300/90 leading-relaxed">
                Hệ thống áp dụng kiến trúc <strong>2-Layer Verification (Bảo mật 2 tầng)</strong> để ngăn chặn việc người dùng mạo danh Admin:
              </p>
              
              <div className="space-y-2 pt-1 font-mono text-[11px]">
                <div className="p-2.5 bg-white dark:bg-slate-900 rounded-xl border border-amber-300/50 dark:border-amber-700/50">
                  <span className="text-indigo-600 dark:text-indigo-400 font-bold">1. Phía React Frontend:</span>
                  <p className="font-sans text-slate-600 dark:text-slate-300 mt-1">
                    Kiểm tra trạng thái <code className="text-amber-600 font-mono">currentUser.role === 'admin'</code> & <code className="text-amber-600 font-mono">isAdminVerified: true</code> trước khi render nút "Quản lý người dùng", menu sửa/xóa bài người khác.
                  </p>
                </div>

                <div className="p-2.5 bg-white dark:bg-slate-900 rounded-xl border border-amber-300/50 dark:border-amber-700/50">
                  <span className="text-indigo-600 dark:text-indigo-400 font-bold">2. Phía Python Flask + SQLite Backend:</span>
                  <p className="font-sans text-slate-600 dark:text-slate-300 mt-1">
                    Bảo vệ bằng Custom Decorator <code className="text-emerald-600 font-mono font-bold">@admin_required</code>, kiểm tra Session/JWT Cookie đã được ký bằng SECRET_KEY và trường <code className="text-emerald-600 font-mono font-bold">is_admin</code> trong bảng SQLite.
                  </p>
                </div>
              </div>
            </div>

            {/* Python Decorator Code Preview */}
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
              <div className="bg-slate-950 p-3 text-slate-300 font-mono text-[11px] flex items-center justify-between border-b border-slate-800">
                <span className="flex items-center gap-1.5 text-indigo-400 font-bold">
                  <Code2 className="w-3.5 h-3.5" />
                  Mã nguồn Python Flask Decorator
                </span>
                <span className="text-[10px] text-slate-500">auth_decorators.py</span>
              </div>
              <pre className="p-3 bg-slate-900 text-slate-200 font-mono text-[10px] overflow-x-auto leading-relaxed">
{`from functools import wraps
from flask import session, abort, redirect, url_for, flash

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('user_id') or session.get('role') != 'admin':
            flash('Yêu cầu quyền Quản trị viên!', 'danger')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function`}
              </pre>
            </div>
          </div>
        )}

        {/* Modal Footer */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-400">
          <span>Tài khoản hiện tại: <strong className="text-slate-700 dark:text-slate-300">{currentUser.name}</strong></span>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 transition-colors"
          >
            Đóng
          </button>
        </div>

      </div>
    </div>
  );
};
