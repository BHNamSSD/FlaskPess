import React, { useState } from 'react';
import { User, UserRole } from '../types';
import { 
  Users, 
  Crown, 
  ShieldCheck, 
  UserCheck, 
  LogIn, 
  Check, 
  X, 
  Sparkles, 
  Info,
  Shield,
  FileText,
  MessageSquare,
  Trash2,
  Edit
} from 'lucide-react';

interface AccountSwitcherModalProps {
  isOpen: boolean;
  onClose: () => void;
  users: User[];
  currentUser: User;
  onSelectUser: (user: User) => void;
  showToast: (text: string, type?: 'success' | 'error' | 'info') => void;
}

export const AccountSwitcherModal: React.FC<AccountSwitcherModalProps> = ({
  isOpen,
  onClose,
  users,
  currentUser,
  onSelectUser,
  showToast,
}) => {
  const [activeTab, setActiveTab] = useState<'switch' | 'permissions'>('switch');

  if (!isOpen) return null;

  const handleChoose = (user: User) => {
    if (user.status === 'banned') {
      showToast(`Tài khoản "${user.name}" đang bị khóa, không thể đăng nhập!`, 'error');
      return;
    }
    onSelectUser(user);
    showToast(`Đã chuyển sang tài khoản: ${user.name} (${user.role === 'admin' ? '👑 Quản trị viên' : '👤 Người dùng'})`, 'success');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl space-y-5">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-600/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                Chuyển đổi tài khoản & Phân quyền
              </h3>
              <p className="text-xs text-slate-400">
                Thử nghiệm giao diện giữa vai trò Admin và Người dùng
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switchers */}
        <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800/80 p-1 rounded-xl">
          <button
            onClick={() => setActiveTab('switch')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
              activeTab === 'switch'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-300'
            }`}
          >
            Danh sách tài khoản demo
          </button>
          <button
            onClick={() => setActiveTab('permissions')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
              activeTab === 'permissions'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-300'
            }`}
          >
            Bảng so sánh quyền hạn (RBAC)
          </button>
        </div>

        {/* Tab 1: Fast Account Switcher */}
        {activeTab === 'switch' && (
          <div className="space-y-3">
            <div className="text-xs text-slate-500 dark:text-slate-400">
              Chọn 1 tài khoản bên dưới để trải nghiệm phân quyền hệ thống:
            </div>

            <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
              {users.map((user) => {
                const isSelected = user.id === currentUser.id;
                const isBanned = user.status === 'banned';

                return (
                  <div
                    key={user.id}
                    onClick={() => handleChoose(user)}
                    className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                      isSelected
                        ? 'bg-indigo-50/60 dark:bg-indigo-950/40 border-indigo-500/50 shadow-xs'
                        : isBanned
                        ? 'bg-slate-50 dark:bg-slate-950/40 border-slate-200 dark:border-slate-800 opacity-60'
                        : 'bg-slate-50/50 dark:bg-slate-950/60 border-slate-200/80 dark:border-slate-800 hover:border-indigo-400/60 dark:hover:border-indigo-500/60'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="relative flex-shrink-0">
                        <img
                          src={user.avatar}
                          alt={user.name}
                          className="w-10 h-10 rounded-full object-cover border border-slate-200 dark:border-slate-700"
                          referrerPolicy="no-referrer"
                        />
                        {user.role === 'admin' && (
                          <span className="absolute -top-1 -right-1 w-4 h-4 bg-amber-500 text-slate-950 rounded-full flex items-center justify-center text-[9px] font-bold">
                            👑
                          </span>
                        )}
                      </div>

                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-slate-900 dark:text-white truncate">
                            {user.name}
                          </span>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border uppercase ${
                            user.role === 'admin'
                              ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30'
                              : 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border-indigo-500/30'
                          }`}>
                            {user.role === 'admin' ? '👑 Admin' : '👤 User'}
                          </span>
                        </div>
                        <div className="text-xs text-slate-400 font-mono truncate">
                          @{user.username} • {user.email}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 flex-shrink-0">
                      {isBanned && (
                        <span className="text-[11px] font-bold text-rose-500 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20">
                          Bị khóa
                        </span>
                      )}
                      {isSelected ? (
                        <div className="w-7 h-7 rounded-full bg-indigo-600 text-white flex items-center justify-center">
                          <Check className="w-4 h-4" />
                        </div>
                      ) : (
                        <button
                          type="button"
                          className="px-3 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-semibold hover:bg-indigo-600 hover:text-white transition-colors"
                        >
                          Chọn
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Tab 2: Permission Matrix */}
        {activeTab === 'permissions' && (
          <div className="space-y-3 text-xs">
            <div className="p-3.5 bg-indigo-50/50 dark:bg-indigo-950/40 border border-indigo-200/60 dark:border-indigo-800/60 rounded-2xl flex items-start gap-2.5">
              <Shield className="w-4 h-4 text-indigo-600 dark:text-indigo-400 mt-0.5 flex-shrink-0" />
              <p className="text-indigo-900 dark:text-indigo-200 leading-relaxed">
                Hệ thống phân quyền (RBAC) tự động áp dụng trên thanh điều hướng, quyền chỉnh sửa/xóa bài viết, kiểm duyệt bình luận và trang quản lý người dùng.
              </p>
            </div>

            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden divide-y divide-slate-100 dark:divide-slate-800">
              <div className="p-3 bg-slate-50 dark:bg-slate-950/60 font-bold text-slate-700 dark:text-slate-300 grid grid-cols-3">
                <span>Chức năng</span>
                <span className="text-center text-amber-600 dark:text-amber-400 font-bold">👑 Admin</span>
                <span className="text-center text-indigo-600 dark:text-indigo-400 font-bold">👤 User</span>
              </div>
              <div className="p-3 grid grid-cols-3 items-center">
                <span>Trang Quản lý người dùng</span>
                <span className="text-center text-emerald-600 font-bold">✓ Toàn quyền</span>
                <span className="text-center text-rose-500 font-bold">✕ Không thể xem</span>
              </div>
              <div className="p-3 grid grid-cols-3 items-center bg-slate-50/40 dark:bg-slate-950/20">
                <span>Đổi quyền / Khóa tài khoản</span>
                <span className="text-center text-emerald-600 font-bold">✓ Có</span>
                <span className="text-center text-rose-500 font-bold">✕ Không</span>
              </div>
              <div className="p-3 grid grid-cols-3 items-center">
                <span>Sửa & Xóa bài viết</span>
                <span className="text-center text-emerald-600 font-bold">✓ Tất cả bài viết</span>
                <span className="text-center text-indigo-600 font-semibold">Chỉ bài của mình</span>
              </div>
              <div className="p-3 grid grid-cols-3 items-center bg-slate-50/40 dark:bg-slate-950/20">
                <span>Đăng bài viết mới</span>
                <span className="text-center text-emerald-600 font-bold">✓ Có</span>
                <span className="text-center text-emerald-600 font-bold">✓ Có</span>
              </div>
              <div className="p-3 grid grid-cols-3 items-center">
                <span>Bình luận & Thả tim</span>
                <span className="text-center text-emerald-600 font-bold">✓ Có</span>
                <span className="text-center text-emerald-600 font-bold">✓ Có</span>
              </div>
            </div>
          </div>
        )}

        {/* Modal Footer */}
        <div className="flex justify-end pt-3 border-t border-slate-100 dark:border-slate-800">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 transition-colors"
          >
            Đóng
          </button>
        </div>

      </div>
    </div>
  );
};
