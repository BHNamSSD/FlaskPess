import React from 'react';
import { Post, User as UserType } from '../types';
import { 
  Clock, 
  Eye, 
  Heart, 
  MessageSquare, 
  Edit3, 
  Trash2, 
  ArrowRight,
  User,
  Share2,
  ShieldAlert
} from 'lucide-react';

interface PostCardProps {
  post: Post;
  searchQuery?: string;
  onRead: (id: string) => void;
  onEdit: (id: string) => void;
  onDelete: (id: string) => void;
  onLike: (id: string) => void;
  onTagClick?: (tag: string) => void;
  onCategoryClick?: (category: string) => void;
  viewMode?: 'grid' | 'list';
  currentUser?: UserType;
}

export const PostCard: React.FC<PostCardProps> = ({
  post,
  searchQuery = '',
  onRead,
  onEdit,
  onDelete,
  onLike,
  onTagClick,
  onCategoryClick,
  viewMode = 'grid',
  currentUser,
}) => {
  const highlightMatch = (text: string, query: string) => {
    if (!query) return text;
    const parts = text.split(new RegExp(`(${query})`, 'gi'));
    return parts.map((part, i) =>
      part.toLowerCase() === query.toLowerCase() ? (
        <mark key={i} className="bg-amber-200 dark:bg-amber-900/60 text-amber-950 dark:text-amber-100 rounded px-0.5 font-medium">
          {part}
        </mark>
      ) : (
        part
      )
    );
  };

  const formattedDate = new Date(post.createdAt).toLocaleDateString('vi-VN', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });

  const isAdmin = currentUser?.role === 'admin';
  const isAuthor = currentUser && (
    post.author.name.toLowerCase() === currentUser.name.toLowerCase() ||
    post.author.name.toLowerCase() === currentUser.username.toLowerCase()
  );
  const canManage = isAdmin || isAuthor;


  if (viewMode === 'list') {
    return (
      <div 
        id={`post-card-${post.id}`}
        className="group bg-white dark:bg-slate-900/60 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 shadow-xs hover:shadow-xl hover:shadow-indigo-500/5 hover:border-indigo-500/40 dark:hover:border-indigo-500/40 transition-all flex flex-col md:flex-row gap-5 items-start md:items-center"
      >
        {post.coverImage && (
          <div 
            onClick={() => onRead(post.id)}
            className="w-full md:w-56 h-36 rounded-xl overflow-hidden cursor-pointer flex-shrink-0 relative group/img bg-slate-100 dark:bg-slate-800"
          >
            <img 
              src={post.coverImage} 
              alt={post.title}
              className="w-full h-full object-cover group-hover/img:scale-105 transition-transform duration-300"
              referrerPolicy="no-referrer"
            />
            <span className="absolute top-2.5 left-2.5 bg-slate-950/80 backdrop-blur-xs text-indigo-300 text-[10px] font-bold uppercase tracking-wide px-2 py-0.5 rounded-md border border-indigo-500/20">
              {post.category}
            </span>
          </div>
        )}

        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2 mb-2 text-xs text-slate-500 dark:text-slate-400">
            {!post.coverImage && (
              <button 
                onClick={() => onCategoryClick?.(post.category)}
                className="bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 text-[10px] font-bold uppercase px-2.5 py-0.5 rounded-md hover:bg-indigo-500/20"
              >
                {post.category}
              </button>
            )}
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-indigo-500" />
              {formattedDate}
            </span>
            <span>•</span>
            <span>{post.readingTimeMinutes} phút đọc</span>
          </div>

          <h3 
            onClick={() => onRead(post.id)}
            className="text-lg font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 cursor-pointer transition-colors line-clamp-1 mb-2 tracking-tight"
          >
            {highlightMatch(post.title, searchQuery)}
          </h3>

          <p className="text-sm text-slate-600 dark:text-slate-300 line-clamp-2 mb-3">
            {post.excerpt}
          </p>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100 dark:border-slate-800/80">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full bg-indigo-50 dark:bg-indigo-950/80 border border-indigo-200/50 dark:border-indigo-800/50 overflow-hidden flex items-center justify-center text-xs font-semibold text-indigo-600 dark:text-indigo-300">
                {post.author.avatar ? (
                  <img src={post.author.avatar} alt={post.author.name} className="w-full h-full object-cover" />
                ) : (
                  <User className="w-3.5 h-3.5 text-indigo-400" />
                )}
              </div>
              <span className="text-xs font-medium text-slate-700 dark:text-slate-300">{post.author.name}</span>
            </div>

            <div className="flex items-center gap-3">
              <button 
                onClick={() => onLike(post.id)}
                className="flex items-center gap-1 text-xs text-slate-500 hover:text-rose-500 dark:text-slate-400 dark:hover:text-rose-400 transition-colors"
                title="Thích bài viết"
              >
                <Heart className="w-3.5 h-3.5 text-rose-500/80" />
                <span>{post.likes}</span>
              </button>

              <span className="flex items-center gap-1 text-xs text-slate-500 dark:text-slate-400">
                <MessageSquare className="w-3.5 h-3.5" />
                <span>{post.comments?.length || 0}</span>
              </span>

              <span className="flex items-center gap-1 text-xs text-slate-500 dark:text-slate-400">
                <Eye className="w-3.5 h-3.5" />
                <span>{post.views}</span>
              </span>

              {canManage && (
                <div className="flex items-center gap-1 ml-2 pl-2 border-l border-slate-200 dark:border-slate-800">
                  <button
                    onClick={() => onEdit(post.id)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-slate-800 transition-colors"
                    title={isAdmin ? 'Chỉnh sửa bài viết (Quyền Admin)' : 'Chỉnh sửa bài viết của bạn'}
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onDelete(post.id)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-slate-800 transition-colors"
                    title={isAdmin ? 'Xóa bài viết (Quyền Admin)' : 'Xóa bài viết của bạn'}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div 
      id={`post-card-${post.id}`}
      className="group bg-white dark:bg-slate-900/60 rounded-2xl border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-xs hover:shadow-xl hover:shadow-indigo-500/5 hover:border-indigo-500/40 dark:hover:border-indigo-500/40 transition-all duration-200 flex flex-col justify-between"
    >
      <div>
        {/* Cover Image Header */}
        {post.coverImage ? (
          <div 
            onClick={() => onRead(post.id)}
            className="w-full h-48 overflow-hidden cursor-pointer relative bg-slate-100 dark:bg-slate-800"
          >
            <img 
              src={post.coverImage} 
              alt={post.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
              <span className="text-white text-xs font-semibold flex items-center gap-1.5 bg-indigo-600 px-3 py-1.5 rounded-lg shadow-md">
                Đọc bài viết <ArrowRight className="w-3.5 h-3.5" />
              </span>
            </div>
            <button 
              onClick={(e) => {
                e.stopPropagation();
                onCategoryClick?.(post.category);
              }}
              className="absolute top-3 left-3 bg-slate-950/80 backdrop-blur-md text-indigo-300 text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-lg border border-indigo-500/30 shadow-md hover:bg-indigo-600 hover:text-white transition-colors"
            >
              {post.category}
            </button>
          </div>
        ) : (
          <div className="p-5 pb-0 flex justify-between items-center">
            <button 
              onClick={() => onCategoryClick?.(post.category)}
              className="bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-lg border border-indigo-500/20 hover:bg-indigo-600 hover:text-white transition-colors"
            >
              {post.category}
            </button>
            <span className="text-xs text-slate-400">{post.readingTimeMinutes} phút đọc</span>
          </div>
        )}

        {/* Card Body */}
        <div className="p-5">
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mb-2">
            <Clock className="w-3.5 h-3.5 text-indigo-500" />
            <span>{formattedDate}</span>
            {post.coverImage && (
              <>
                <span>•</span>
                <span>{post.readingTimeMinutes} phút đọc</span>
              </>
            )}
          </div>

          <h3 
            onClick={() => onRead(post.id)}
            className="text-lg font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 cursor-pointer transition-colors line-clamp-2 mb-2 leading-snug tracking-tight"
          >
            {highlightMatch(post.title, searchQuery)}
          </h3>

          <p className="text-sm text-slate-600 dark:text-slate-300 line-clamp-3 mb-4 leading-relaxed">
            {post.excerpt}
          </p>

          {/* Tags */}
          {post.tags && post.tags.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mb-4">
              {post.tags.slice(0, 3).map((tag, idx) => (
                <button
                  key={idx}
                  onClick={(e) => {
                    e.stopPropagation();
                    onTagClick?.(tag);
                  }}
                  className="text-[11px] font-medium text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 hover:text-indigo-600 dark:hover:bg-indigo-950/60 dark:hover:text-indigo-300 px-2 py-0.5 rounded-md transition-colors"
                >
                  #{tag}
                </button>
              ))}
              {post.tags.length > 3 && (
                <span className="text-[11px] text-slate-400 self-center">
                  +{post.tags.length - 3}
                </span>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Card Footer */}
      <div className="px-5 py-3.5 bg-slate-50/70 dark:bg-slate-800/40 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-full bg-indigo-100 dark:bg-indigo-950/80 border border-indigo-200/50 dark:border-indigo-800/50 overflow-hidden flex items-center justify-center text-xs font-bold text-indigo-600 dark:text-indigo-300">
            {post.author.avatar ? (
              <img src={post.author.avatar} alt={post.author.name} className="w-full h-full object-cover" />
            ) : (
              post.author.name.charAt(0)
            )}
          </div>
          <span className="text-xs font-semibold text-slate-700 dark:text-slate-200 truncate max-w-[100px]">
            {post.author.name}
          </span>
        </div>

        <div className="flex items-center gap-2.5">
          <button 
            onClick={() => onLike(post.id)}
            className="flex items-center gap-1 text-xs text-slate-500 hover:text-rose-500 dark:text-slate-400 dark:hover:text-rose-400 transition-colors"
            title="Thích bài viết"
          >
            <Heart className="w-3.5 h-3.5 text-rose-500/80" />
            <span>{post.likes}</span>
          </button>

          <span className="flex items-center gap-1 text-xs text-slate-400" title="Bình luận">
            <MessageSquare className="w-3.5 h-3.5" />
            <span>{post.comments?.length || 0}</span>
          </span>

          {canManage && (
            <div className="flex items-center gap-1 border-l border-slate-200 dark:border-slate-700 pl-2">
              <button
                onClick={() => onEdit(post.id)}
                className="p-1 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-slate-700 transition-colors"
                title={isAdmin ? 'Sửa bài viết (Quyền Admin)' : 'Sửa bài viết của bạn'}
              >
                <Edit3 className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => onDelete(post.id)}
                className="p-1 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-slate-700 transition-colors"
                title={isAdmin ? 'Xóa bài viết (Quyền Admin)' : 'Xóa bài viết của bạn'}
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
