import React, { useState, useEffect, useRef } from 'react';
import { Post, CurrentView, User } from '../types';
import { 
  Sun, 
  Moon, 
  Search, 
  PlusCircle, 
  Code2, 
  BookOpen, 
  X, 
  ArrowRight,
  Sparkles,
  Menu,
  FileText,
  ShieldCheck,
  Users,
  Crown,
  ChevronDown,
  LogIn,
  UserPlus,
  KeyRound
} from 'lucide-react';

interface NavbarProps {
  currentView: CurrentView;
  onNavigate: (view: CurrentView, postId?: string) => void;
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
  posts: Post[];
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedCategory: string;
  onSelectCategory: (cat: string) => void;
  currentUser: User;
  onOpenAuth: (tab?: 'login' | 'register' | 'switch' | 'verify-admin') => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  theme,
  onToggleTheme,
  posts,
  searchQuery,
  onSearchChange,
  selectedCategory,
  onSelectCategory,
  currentUser,
  onOpenAuth,
}) => {
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);


  // Filter posts for the instant search dropdown
  const searchResults = searchQuery.trim()
    ? posts.filter((post) => {
        const q = searchQuery.toLowerCase();
        return (
          post.title.toLowerCase().includes(q) ||
          post.content.toLowerCase().includes(q) ||
          post.category.toLowerCase().includes(q) ||
          post.tags.some((t) => t.toLowerCase().includes(q))
        );
      }).slice(0, 6)
    : [];

  // Close dropdown on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        searchContainerRef.current &&
        !searchContainerRef.current.contains(event.target as Node)
      ) {
        setIsSearchFocused(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectSearchResult = (postId: string) => {
    setIsSearchFocused(false);
    onNavigate('post-detail', postId);
  };

  const highlightMatch = (text: string, query: string) => {
    if (!query) return text;
    const parts = text.split(new RegExp(`(${query})`, 'gi'));
    return parts.map((part, i) =>
      part.toLowerCase() === query.toLowerCase() ? (
        <mark key={i} className="bg-amber-200 dark:bg-amber-900/60 text-amber-950 dark:text-amber-100 rounded px-0.5 font-medium">
          {part}
        </mark>
      ) : (
        part
      )
    );
  };

  return (
    <header className="sticky top-0 z-40 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-3">
          
          {/* Logo / Brand */}
          <div 
            id="brand-logo"
            onClick={() => {
              onNavigate('home');
              onSearchChange('');
              onSelectCategory('Tất cả');
            }}
            className="flex items-center gap-3 cursor-pointer group flex-shrink-0"
          >
            <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-bold italic shadow-md shadow-indigo-500/30 group-hover:scale-105 transition-transform">
              B
            </div>
            <div>
              <div className="font-bold text-lg leading-tight tracking-tight flex items-center gap-1 text-slate-900 dark:text-white">
                Flask<span className="text-indigo-600 dark:text-indigo-400">Press</span>
              </div>
              <div className="text-[10px] uppercase font-bold tracking-widest text-slate-400 dark:text-slate-500">
                SQLite • Markdown
              </div>
            </div>
          </div>

          {/* Real-time Top Instant Search Bar */}
          <div 
            ref={searchContainerRef}
            className="relative flex-1 max-w-md hidden sm:block mx-4"
          >
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 dark:text-slate-500">
                <Search className="h-4 w-4" />
              </div>
              <input
                id="top-search-input"
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  onSearchChange(e.target.value);
                  setIsSearchFocused(true);
                }}
                onFocus={() => setIsSearchFocused(true)}
                placeholder="Tìm kiếm bài viết tức thì..."
                className="w-full pl-9 pr-8 py-2 text-sm bg-slate-100 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 rounded-full focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 transition-all shadow-inner"
              />
              {searchQuery && (
                <button
                  onClick={() => onSearchChange('')}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>

            {/* Instant Search Dropdown Results */}
            {isSearchFocused && searchQuery.trim().length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-2 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="p-3 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 flex items-center justify-between text-xs font-semibold text-slate-500 dark:text-slate-400 px-4">
                  <span className="uppercase tracking-wider text-[11px]">Kết quả tìm kiếm cho "{searchQuery}"</span>
                  <span className="bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 px-2 py-0.5 rounded-full text-[11px] font-bold border border-indigo-500/20">
                    {searchResults.length} bài viết
                  </span>
                </div>

                {searchResults.length > 0 ? (
                  <div className="max-h-80 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/60">
                    {searchResults.map((post) => (
                      <div
                        key={post.id}
                        onClick={() => handleSelectSearchResult(post.id)}
                        className="p-3.5 hover:bg-slate-50 dark:hover:bg-slate-800/60 cursor-pointer transition-colors flex items-start gap-3 group"
                      >
                        <div className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700/80 text-indigo-600 dark:text-indigo-400 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <FileText className="w-4 h-4" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-0.5">
                            <span className="text-[10px] font-bold uppercase tracking-wide text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200/60 dark:border-indigo-800/60 px-2 py-0.5 rounded">
                              {post.category}
                            </span>
                            <span className="text-[11px] text-slate-400">
                              {new Date(post.createdAt).toLocaleDateString('vi-VN')}
                            </span>
                          </div>
                          <h4 className="text-sm font-semibold text-slate-900 dark:text-white truncate group-hover:text-indigo-600 dark:group-hover:text-indigo-400">
                            {highlightMatch(post.title, searchQuery)}
                          </h4>
                          <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
                            {post.excerpt}
                          </p>
                        </div>
                        <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 group-hover:translate-x-0.5 transition-all flex-shrink-0 self-center" />
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-6 text-center text-slate-500 dark:text-slate-400 text-sm">
                    <p className="font-medium">Không tìm thấy bài viết phù hợp</p>
                    <p className="text-xs text-slate-400 mt-1">Hãy thử tìm theo từ khóa khác hoặc danh mục khác.</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Action Buttons & Navigation */}
          <div className="flex items-center gap-2 sm:gap-2.5">
            
            {/* Admin Exclusive: User Management View Button */}
            {currentUser.role === 'admin' && (
              <button
                id="btn-admin-user-management"
                onClick={() => onNavigate('users-management')}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs sm:text-sm font-semibold rounded-xl transition-all ${
                  currentView === 'users-management'
                    ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/40 shadow-xs'
                    : 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 border border-amber-300/60 dark:border-amber-700/60 hover:bg-amber-100 dark:hover:bg-amber-900/60'
                }`}
                title="Trang quản lý người dùng & phân quyền hệ thống (Dành riêng cho Admin)"
              >
                <ShieldCheck className="w-4 h-4 text-amber-500" />
                <span className="hidden md:inline">Quản lý người dùng</span>
                <span className="md:hidden">Quản trị</span>
              </button>
            )}

            {/* View Python Flask Source Button */}
            <button
              id="btn-view-flask-code"
              onClick={() => onNavigate('flask-code')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs sm:text-sm font-medium rounded-xl transition-all ${
                currentView === 'flask-code'
                  ? 'bg-indigo-600/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/30'
                  : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800/80 dark:hover:bg-slate-700/80 text-slate-700 dark:text-slate-300'
              }`}
              title="Xem & Tải mã nguồn Python Flask + SQLite"
            >
              <Code2 className="w-4 h-4 text-indigo-500" />
              <span className="hidden lg:inline">Mã nguồn Flask</span>
            </button>

            {/* New Post Button */}
            <button
              id="btn-create-new-post"
              onClick={() => onNavigate('create')}
              className="flex items-center gap-1.5 px-3.5 sm:px-4 py-2 text-xs sm:text-sm font-medium rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-500/20 transition-all hover:scale-105 active:scale-95"
            >
              <PlusCircle className="w-4 h-4" />
              <span className="hidden sm:inline">Viết bài mới</span>
            </button>

            {/* User Account & Login/Register Menu Trigger */}
            <div className="flex items-center gap-1.5">
              <button
                id="btn-account-switcher"
                onClick={() => onOpenAuth('switch')}
                className={`flex items-center gap-2 p-1 sm:px-2.5 sm:py-1 rounded-xl border transition-all text-xs font-semibold ${
                  currentUser.role === 'admin'
                    ? 'border-amber-400/40 dark:border-amber-600/40 bg-amber-50/60 dark:bg-amber-950/30 text-amber-900 dark:text-amber-100 hover:bg-amber-100/80'
                    : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 hover:bg-slate-100'
                }`}
                title="Nhấn để Đăng nhập, Đăng ký hoặc Chuyển tài khoản"
              >
                <div className="relative">
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.name}
                    className="w-7 h-7 rounded-full object-cover border border-slate-300 dark:border-slate-600"
                    referrerPolicy="no-referrer"
                  />
                  {currentUser.role === 'admin' && (
                    <span className="absolute -top-1 -right-1 text-[9px]">👑</span>
                  )}
                </div>
                <div className="hidden sm:flex flex-col items-start text-left">
                  <span className="text-[11px] font-bold leading-tight truncate max-w-[80px]">
                    {currentUser.name}
                  </span>
                  <span className={`text-[9px] uppercase font-bold tracking-wider leading-tight ${
                    currentUser.role === 'admin' ? 'text-amber-600 dark:text-amber-400' : 'text-indigo-600 dark:text-indigo-400'
                  }`}>
                    {currentUser.role === 'admin' ? 'Admin' : 'User'}
                  </span>
                </div>
                <ChevronDown className="w-3.5 h-3.5 opacity-60 hidden sm:inline" />
              </button>

              <button
                id="btn-login-register-direct"
                onClick={() => onOpenAuth('login')}
                className="hidden lg:flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-indigo-400 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                title="Mở cửa sổ Đăng nhập / Đăng ký"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Đăng nhập</span>
              </button>
            </div>

            {/* Dark Mode Toggle Button */}
            <button
              id="btn-theme-toggle"
              onClick={onToggleTheme}
              aria-label="Chuyển đổi chế độ tối / sáng"
              className="w-8 h-8 sm:w-9 sm:h-9 flex items-center justify-center rounded-xl border border-slate-200 dark:border-slate-700/80 bg-white dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/80 hover:text-slate-900 dark:hover:text-white transition-colors"
              title={theme === 'dark' ? 'Chuyển sang giao diện Sáng' : 'Chuyển sang giao diện Tối'}
            >
              {theme === 'dark' ? (
                <Sun className="w-4 h-4 text-amber-400" />
              ) : (
                <Moon className="w-4 h-4 text-slate-600" />
              )}
            </button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="sm:hidden w-8 h-8 flex items-center justify-center rounded-xl border border-slate-200 dark:border-slate-700/80 bg-white dark:bg-slate-800/80 text-slate-600 dark:text-slate-300"
            >
              <Menu className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Mobile Search Bar & Menu */}
        {mobileMenuOpen && (
          <div className="sm:hidden pb-4 pt-2 border-t border-slate-200 dark:border-slate-800 space-y-3">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Tìm kiếm bài viết..."
                className="w-full pl-9 pr-4 py-2 text-sm bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>

            {/* Role indicator in mobile */}
            <div 
              onClick={() => {
                onOpenAuth('login');
                setMobileMenuOpen(false);
              }}
              className="flex items-center justify-between p-2.5 bg-slate-100 dark:bg-slate-800/80 rounded-xl cursor-pointer"
            >
              <div className="flex items-center gap-2">
                <img src={currentUser.avatar} alt={currentUser.name} className="w-7 h-7 rounded-full object-cover" />
                <div>
                  <div className="text-xs font-bold text-slate-900 dark:text-white">{currentUser.name}</div>
                  <div className="text-[10px] text-slate-500">@{currentUser.username}</div>
                </div>
              </div>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                currentUser.role === 'admin'
                  ? 'bg-amber-500/10 text-amber-600 border-amber-500/30'
                  : 'bg-indigo-500/10 text-indigo-600 border-indigo-500/30'
              }`}>
                {currentUser.role === 'admin' ? '👑 Admin' : '👤 User'} • Đăng nhập / Đổi
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  onNavigate('home');
                  setMobileMenuOpen(false);
                }}
                className="py-2 text-xs font-medium text-center rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200"
              >
                Tất cả bài viết
              </button>
              
              {currentUser.role === 'admin' && (
                <button
                  onClick={() => {
                    onNavigate('users-management');
                    setMobileMenuOpen(false);
                  }}
                  className="py-2 text-xs font-medium text-center rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/30"
                >
                  Quản lý người dùng
                </button>
              )}

              <button
                onClick={() => {
                  onNavigate('flask-code');
                  setMobileMenuOpen(false);
                }}
                className="py-2 text-xs font-medium text-center rounded-xl bg-indigo-600/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 col-span-2"
              >
                Mã nguồn Flask + SQLite
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};
