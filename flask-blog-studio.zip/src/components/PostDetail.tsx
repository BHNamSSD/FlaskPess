import React, { useState } from 'react';
import { Post, Comment, CurrentView, User as UserType } from '../types';
import { renderMarkdown, extractTableOfContents } from '../utils/markdown';
import confetti from 'canvas-confetti';
import { 
  ArrowLeft, 
  Calendar, 
  Clock, 
  Eye, 
  Heart, 
  MessageSquare, 
  Edit3, 
  Trash2, 
  Share2, 
  Check, 
  Send, 
  User, 
  ListTree, 
  Bookmark,
  Sparkles,
  Tag,
  ShieldCheck
} from 'lucide-react';

interface PostDetailProps {
  post: Post;
  onNavigate: (view: CurrentView, postId?: string) => void;
  onEdit: (postId: string) => void;
  onDelete: (postId: string) => void;
  onLike: (postId: string) => void;
  onAddComment: (postId: string, comment: Omit<Comment, 'id' | 'createdAt'>) => void;
  onDeleteComment: (postId: string, commentId: string) => void;
  showToast: (msg: string, type?: 'success' | 'info' | 'error') => void;
  currentUser?: UserType;
}

export const PostDetail: React.FC<PostDetailProps> = ({
  post,
  onNavigate,
  onEdit,
  onDelete,
  onLike,
  onAddComment,
  onDeleteComment,
  showToast,
  currentUser,
}) => {
  const [copied, setCopied] = useState(false);
  const [commentContent, setCommentContent] = useState('');

  const isAdmin = currentUser?.role === 'admin';
  const isAuthor = currentUser && (
    post.author.name.toLowerCase() === currentUser.name.toLowerCase() ||
    post.author.name.toLowerCase() === currentUser.username.toLowerCase()
  );
  const canManage = isAdmin || isAuthor;

  const renderedHtml = renderMarkdown(post.content);
  const toc = extractTableOfContents(post.content);

  const formattedDate = new Date(post.createdAt).toLocaleDateString('vi-VN', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const handleLikeWithConfetti = (e: React.MouseEvent) => {
    onLike(post.id);
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (rect.left + rect.width / 2) / window.innerWidth;
    const y = (rect.top + rect.height / 2) / window.innerHeight;

    confetti({
      origin: { x, y },
      particleCount: 35,
      spread: 60,
      colors: ['#ef4444', '#ec4899', '#3b82f6', '#8b5cf6'],
    });
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    showToast('Đã sao chép liên kết bài viết vào bộ nhớ tạm!', 'success');
    setTimeout(() => setCopied(false), 3000);
  };

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentContent.trim()) {
      showToast('Vui lòng nhập nội dung bình luận!', 'error');
      return;
    }

    const authorName = currentUser?.name || 'Thành viên cộng đồng';
    const authorAvatar = currentUser?.avatar || `https://api.dicebear.com/7.x/notionists/svg?seed=${encodeURIComponent(authorName)}`;

    onAddComment(post.id, {
      author: authorName,
      authorId: currentUser?.id,
      authorUsername: currentUser?.username,
      authorRole: currentUser?.role || 'user',
      content: commentContent.trim(),
      avatarUrl: authorAvatar,
    });

    setCommentContent('');
    showToast(`Đã gửi bình luận dưới tên "${authorName}"!`, 'success');
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Top Nav Action Bar */}
      <div className="flex items-center justify-between gap-4 mb-6">
        <button
          onClick={() => onNavigate('home')}
          className="inline-flex items-center gap-2 text-sm font-semibold text-slate-600 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Quay lại danh sách</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={handleShare}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700/80 bg-white dark:bg-slate-800/80 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors shadow-2xs"
            title="Chia sẻ bài viết"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Share2 className="w-3.5 h-3.5" />}
            <span>{copied ? 'Đã sao chép!' : 'Chia sẻ'}</span>
          </button>

          {canManage && (
            <>
              <button
                onClick={() => onEdit(post.id)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700/80 bg-white dark:bg-slate-800/80 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-slate-700 transition-colors shadow-2xs"
                title={isAdmin ? 'Chỉnh sửa bài viết (Quyền Quản trị viên)' : 'Chỉnh sửa bài viết của bạn'}
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Sửa bài</span>
              </button>

              <button
                onClick={() => onDelete(post.id)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-rose-200 dark:border-rose-900/50 bg-rose-50/50 dark:bg-rose-950/30 text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-100 dark:hover:bg-rose-900/50 transition-colors shadow-2xs"
                title={isAdmin ? 'Xóa bài viết (Quyền Quản trị viên)' : 'Xóa bài viết của bạn'}
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Xóa</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Article Container */}
      <article className="bg-white dark:bg-slate-900/70 rounded-3xl border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-xs mb-8">
        
        {/* Cover Image Header */}
        {post.coverImage && (
          <div className="w-full h-72 sm:h-96 relative bg-slate-100 dark:bg-slate-800 overflow-hidden">
            <img
              src={post.coverImage}
              alt={post.title}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/20 to-transparent flex items-end p-6 sm:p-8">
              <span className="bg-indigo-600 text-white text-[11px] font-bold uppercase tracking-wider px-3 py-1 rounded-lg shadow-md">
                {post.category}
              </span>
            </div>
          </div>
        )}

        {/* Article Body */}
        <div className="p-6 sm:p-10 lg:p-12">
          
          {/* Category & Meta info */}
          <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 dark:text-slate-400 mb-4">
            {!post.coverImage && (
              <span className="bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 font-bold uppercase text-[10px] tracking-wide px-3 py-1 rounded-lg">
                {post.category}
              </span>
            )}
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-indigo-500" />
              {formattedDate}
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-indigo-500" />
              {post.readingTimeMinutes} phút đọc
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <Eye className="w-3.5 h-3.5 text-indigo-500" />
              {post.views} lượt xem
            </span>
          </div>

          {/* Title */}
          <h1 className="text-2xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight leading-tight mb-6">
            {post.title}
          </h1>

          {/* Author Bio Card */}
          <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/80 border border-slate-200/70 dark:border-slate-800 mb-8">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-full overflow-hidden bg-indigo-100 dark:bg-indigo-950 border border-indigo-200 dark:border-indigo-800 flex items-center justify-center font-bold text-indigo-600 dark:text-indigo-300">
                {post.author.avatar ? (
                  <img src={post.author.avatar} alt={post.author.name} className="w-full h-full object-cover" />
                ) : (
                  <User className="w-6 h-6 text-indigo-500" />
                )}
              </div>
              <div>
                <div className="font-bold text-sm text-slate-900 dark:text-white">{post.author.name}</div>
                <div className="text-xs text-slate-500 dark:text-slate-400">{post.author.role || 'Tác giả'}</div>
              </div>
            </div>

            <button
              onClick={handleLikeWithConfetti}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 dark:hover:bg-rose-950/70 text-rose-600 dark:text-rose-400 font-bold text-xs sm:text-sm transition-all active:scale-95 border border-rose-200/50 dark:border-rose-900/50"
              title="Thích bài viết"
            >
              <Heart className="w-4 h-4 fill-rose-500 text-rose-500" />
              <span>{post.likes} Yêu thích</span>
            </button>
          </div>

          {/* Table of Contents (if >= 2 headings) */}
          {toc.length >= 2 && (
            <div className="mb-8 p-5 bg-indigo-50/30 dark:bg-slate-950/60 rounded-2xl border border-indigo-100 dark:border-slate-800">
              <div className="text-xs font-bold uppercase tracking-wider text-indigo-900 dark:text-indigo-400 mb-3 flex items-center gap-2">
                <ListTree className="w-4 h-4 text-indigo-500" />
                Mục lục bài viết
              </div>
              <ul className="space-y-1.5 text-xs sm:text-sm">
                {toc.map((item, idx) => (
                  <li key={idx} className={item.level === 1 ? 'font-semibold text-slate-800 dark:text-slate-200' : 'pl-4 text-slate-600 dark:text-slate-400'}>
                    <a href={`#${item.id}`} className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">
                      {item.text}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Rendered Markdown Content */}
          <div
            className="markdown-body my-6"
            dangerouslySetInnerHTML={{ __html: renderedHtml }}
          />

          {/* Tags */}
          {post.tags && post.tags.length > 0 && (
            <div className="mt-8 pt-6 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400 flex items-center gap-1 mr-1">
                <Tag className="w-3.5 h-3.5 text-indigo-500" />
                Thẻ chủ đề:
              </span>
              {post.tags.map((tag, idx) => (
                <span
                  key={idx}
                  className="text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-3 py-1 rounded-lg"
                >
                  #{tag}
                </span>
              ))}
            </div>
          )}
        </div>
      </article>

      {/* Comments Section */}
      <section className="bg-white dark:bg-slate-900/70 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 sm:p-8 shadow-xs">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-indigo-500" />
            Bình luận & Thảo luận ({post.comments?.length || 0})
          </h3>
        </div>

        {/* New Comment Form */}
        <form onSubmit={handleCommentSubmit} className="mb-8 p-4 sm:p-5 rounded-2xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200/60 dark:border-slate-800 space-y-3.5">
          {/* Active User Identity Info Banner */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-200/70 dark:border-slate-800">
            <div className="flex items-center gap-2.5">
              <img
                src={currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'}
                alt={currentUser?.name || 'User'}
                className="w-7 h-7 rounded-full object-cover border border-slate-200 dark:border-slate-700 shadow-2xs"
                referrerPolicy="no-referrer"
              />
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500 dark:text-slate-400">Bình luận với tư cách:</span>
                <span className="text-xs font-bold text-slate-900 dark:text-white">
                  {currentUser?.name || 'Thành viên'}
                </span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border uppercase ${
                  currentUser?.role === 'admin'
                    ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400 border-amber-500/30'
                    : 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border-indigo-500/30'
                }`}>
                  {currentUser?.role === 'admin' ? '👑 Admin' : '👤 Thành viên'}
                </span>
              </div>
            </div>
            <span className="text-[11px] text-slate-400">Tên được gán tự động theo tài khoản</span>
          </div>

          <textarea
            value={commentContent}
            onChange={(e) => setCommentContent(e.target.value)}
            placeholder={`Xin chào ${currentUser?.name || 'bạn'}, hãy chia sẻ suy nghĩ hoặc ý kiến về bài viết này...`}
            rows={3}
            className="w-full text-sm px-3.5 py-2.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none text-slate-900 dark:text-white placeholder:text-slate-400"
            required
          />
          <div className="flex items-center justify-between pt-1">
            <span className="text-[11px] text-slate-400">
              Nhấn Gửi để xuất bản bình luận ngay lập tức.
            </span>
            <button
              type="submit"
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs shadow-md shadow-indigo-500/20 transition-all hover:scale-105 active:scale-95"
            >
              <Send className="w-3.5 h-3.5" />
              Gửi bình luận
            </button>
          </div>
        </form>

        {/* Existing Comments List */}
        <div className="space-y-4">
          {post.comments && post.comments.length > 0 ? (
            post.comments.map((comment) => {
              const isCommentAdmin = comment.authorRole === 'admin' || comment.author.toLowerCase().includes('admin');
              const isCommentAuthor = currentUser && (
                (comment.authorId && comment.authorId === currentUser.id) ||
                (comment.authorUsername && comment.authorUsername === currentUser.username) ||
                (comment.author.toLowerCase() === currentUser.name.toLowerCase())
              );
              const canDeleteComment = isAdmin || isCommentAuthor;

              return (
                <div
                  key={comment.id}
                  className="p-4 rounded-2xl bg-slate-50/70 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 flex items-start justify-between gap-3 group"
                >
                  <div className="flex items-start gap-3 flex-1">
                    {comment.avatarUrl ? (
                      <img
                        src={comment.avatarUrl}
                        alt={comment.author}
                        className="w-8 h-8 rounded-full object-cover border border-slate-200 dark:border-slate-700 flex-shrink-0"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-950 border border-indigo-200/50 dark:border-indigo-800/50 flex items-center justify-center font-bold text-xs text-indigo-600 dark:text-indigo-300 flex-shrink-0">
                        {comment.author.charAt(0).toUpperCase()}
                      </div>
                    )}
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <span className="font-bold text-xs text-slate-900 dark:text-white">{comment.author}</span>
                        {isCommentAdmin && (
                          <span className="text-[10px] font-bold bg-amber-500/15 text-amber-600 dark:text-amber-400 px-1.5 py-0.2 rounded border border-amber-500/30">
                            👑 Admin
                          </span>
                        )}
                        <span className="text-[11px] text-slate-400">
                          {new Date(comment.createdAt).toLocaleString('vi-VN', {
                            month: 'short',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>
                      <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                        {comment.content}
                      </p>
                    </div>
                  </div>

                  {canDeleteComment && (
                    <button
                      onClick={() => onDeleteComment(post.id, comment.id)}
                      className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-rose-500 transition-opacity"
                      title={isAdmin ? "Xóa bình luận này (Quyền Admin)" : "Xóa bình luận của bạn"}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              );
            })
          ) : (
            <div className="text-center py-8 text-slate-400 dark:text-slate-500 text-xs sm:text-sm">
              Chưa có bình luận nào. Hãy là người đầu tiên chia sẻ suy nghĩ của bạn!
            </div>
          )}
        </div>
      </section>
    </div>
  );
};
