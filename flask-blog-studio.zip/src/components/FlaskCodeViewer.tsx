import React, { useState } from 'react';
import { PYTHON_FLASK_PROJECT } from '../data/pythonFlaskSource';
import { FlaskProjectFile } from '../types';
import { 
  FileCode, 
  FolderTree, 
  Copy, 
  Check, 
  Download, 
  Terminal, 
  Sparkles, 
  Layers, 
  FileText, 
  ArrowLeft,
  ChevronRight,
  Database,
  ExternalLink,
  Code
} from 'lucide-react';

interface FlaskCodeViewerProps {
  onBack: () => void;
  showToast: (msg: string, type?: 'success' | 'info' | 'error') => void;
}

export const FlaskCodeViewer: React.FC<FlaskCodeViewerProps> = ({
  onBack,
  showToast,
}) => {
  const [selectedFile, setSelectedFile] = useState<FlaskProjectFile>(PYTHON_FLASK_PROJECT[0]);
  const [copiedFile, setCopiedFile] = useState(false);
  const [copiedAll, setCopiedAll] = useState(false);

  const handleCopySingle = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopiedFile(true);
    showToast(`Đã sao chép nội dung tệp ${selectedFile.name}!`, 'success');
    setTimeout(() => setCopiedFile(false), 2500);
  };

  const handleCopyAllProject = () => {
    let bundle = `# ==========================================\n# BỘ MÃ NGUỒN HOÀN CHỈNH PYTHON FLASK + SQLITE BLOG\n# ==========================================\n\n`;
    PYTHON_FLASK_PROJECT.forEach((f) => {
      bundle += `\n# ==================== FILE: ${f.path} ====================\n`;
      bundle += f.content;
      bundle += `\n\n`;
    });
    navigator.clipboard.writeText(bundle);
    setCopiedAll(true);
    showToast('Đã sao chép toàn bộ dự án Python Flask vào bộ nhớ tạm!', 'success');
    setTimeout(() => setCopiedAll(false), 2500);
  };

  const handleDownloadAll = () => {
    // Generate text bundle of entire project
    let fullBundle = `PROJECT: Flask Blog Platform with SQLite & Markdown\n` +
      `--------------------------------------------------\n\n`;

    PYTHON_FLASK_PROJECT.forEach((f) => {
      fullBundle += `\n=======================================================\n`;
      fullBundle += `PATH: ${f.path}\n`;
      fullBundle += `DESCRIPTION: ${f.description}\n`;
      fullBundle += `=======================================================\n\n`;
      fullBundle += f.content;
      fullBundle += `\n\n`;
    });

    const blob = new Blob([fullBundle], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'flask_blog_complete_project.txt';
    link.click();
    URL.revokeObjectURL(url);
    showToast('Đã tải xuống toàn bộ mã nguồn dự án Flask!', 'success');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
            title="Quay lại Blog"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
                Bộ mã nguồn Python Flask + SQLite
              </h1>
              <span className="text-xs bg-indigo-50 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400 font-bold px-2.5 py-0.5 rounded-full border border-indigo-200 dark:border-indigo-800">
                Flask 3.0 + Bootstrap 5
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Kiến trúc đầy đủ: CSDL SQLite, Live Markdown Editor, API Real-time Search, Dark Mode LocalStorage
            </p>
          </div>
        </div>

        {/* Top Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyAllProject}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors shadow-2xs"
          >
            {copiedAll ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
            <span>{copiedAll ? 'Đã sao chép tất cả!' : 'Sao chép toàn bộ mã'}</span>
          </button>

          <button
            onClick={handleDownloadAll}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-500/20 transition-all hover:scale-105 active:scale-95"
          >
            <Download className="w-4 h-4" />
            <span>Tải về dự án (.txt bundle)</span>
          </button>
        </div>
      </div>

      {/* Terminal Quick Start Guide */}
      <div className="bg-slate-900 text-slate-100 rounded-2xl p-4 sm:p-5 mb-6 border border-slate-800 shadow-lg">
        <div className="flex items-center justify-between mb-3 text-xs text-slate-400">
          <div className="flex items-center gap-2 font-mono">
            <Terminal className="w-4 h-4 text-indigo-400" />
            <span>Hướng dẫn khởi chạy ứng dụng Flask trong 2 bước</span>
          </div>
          <span className="text-[11px] text-emerald-400 font-mono">Ready to Run</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-mono">
          <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800/80">
            <span className="text-slate-500"># Bước 1: Cài đặt thư viện phụ thuộc</span>
            <div className="text-emerald-300 mt-1 font-semibold">pip install -r requirements.txt</div>
          </div>
          <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800/80">
            <span className="text-slate-500"># Bước 2: Chạy server (tự tạo CSDL SQLite)</span>
            <div className="text-indigo-300 mt-1 font-semibold">python app.py</div>
          </div>
        </div>
      </div>

      {/* Main File Explorer & Code Viewer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden">
        
        {/* Left: File Tree Explorer (4 cols) */}
        <div className="lg:col-span-4 p-4 sm:p-5 border-b lg:border-b-0 lg:border-r border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
          <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3 px-2">
            <span className="flex items-center gap-1.5">
              <FolderTree className="w-4 h-4 text-indigo-500" />
              Cấu trúc tệp tin ({PYTHON_FLASK_PROJECT.length})
            </span>
          </div>

          <div className="space-y-1 max-h-[600px] overflow-y-auto pr-1">
            {PYTHON_FLASK_PROJECT.map((file) => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left px-3 py-2.5 rounded-xl text-xs font-mono transition-all flex items-center justify-between ${
                    isSelected
                      ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/30'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <FileCode className={`w-4 h-4 flex-shrink-0 ${isSelected ? 'text-white' : 'text-indigo-500 dark:text-indigo-400'}`} />
                    <span className="truncate">{file.path}</span>
                  </div>
                  <span className={`text-[10px] uppercase font-sans font-semibold px-1.5 py-0.5 rounded ${
                    isSelected ? 'bg-indigo-500 text-white' : 'bg-slate-200 dark:bg-slate-800 text-slate-500'
                  }`}>
                    {file.language}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Code Viewer (8 cols) */}
        <div className="lg:col-span-8 p-4 sm:p-6 flex flex-col justify-between">
          <div>
            {/* Active File Header */}
            <div className="flex flex-wrap items-center justify-between gap-3 pb-3 mb-4 border-b border-slate-200 dark:border-slate-800">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold text-slate-900 dark:text-white font-mono">
                    {selectedFile.path}
                  </span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  {selectedFile.description}
                </p>
              </div>

              <button
                onClick={handleCopySingle}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 transition-colors"
                title="Sao chép nội dung tệp này"
              >
                {copiedFile ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedFile ? 'Đã chép!' : 'Sao chép tệp'}</span>
              </button>
            </div>

            {/* Code Body with Line Numbers */}
            <div className="bg-slate-950 text-slate-100 rounded-2xl p-4 overflow-x-auto max-h-[520px] font-mono text-xs leading-relaxed border border-slate-800 shadow-inner">
              <pre>
                <code>{selectedFile.content}</code>
              </pre>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <span>Dung lượng: ~{Math.ceil(selectedFile.content.length / 1024)} KB</span>
            <span className="text-indigo-600 dark:text-indigo-400 font-semibold">Tương thích: Python 3.9+</span>
          </div>
        </div>
      </div>
    </div>
  );
};
