import React, { useState, useMemo } from 'react';
import { Post, CurrentView, User as UserType } from '../types';
import { PostCard } from './PostCard';
import { 
  LayoutGrid, 
  List, 
  SlidersHorizontal, 
  Sparkles, 
  Tag, 
  Flame, 
  Clock, 
  TrendingUp, 
  X,
  PlusCircle,
  Code2,
  Database,
  Search,
  ShieldCheck,
  Users,
  Crown
} from 'lucide-react';

interface PostListProps {
  posts: Post[];
  searchQuery: string;
  onSearchChange: (q: string) => void;
  selectedCategory: string;
  onSelectCategory: (cat: string) => void;
  selectedTag: string;
  onSelectTag: (tag: string) => void;
  onNavigate: (view: CurrentView, postId?: string) => void;
  onDeletePost: (id: string) => void;
  onLikePost: (id: string) => void;
  currentUser: UserType;
}

type SortOption = 'latest' | 'oldest' | 'views' | 'likes';

export const PostList: React.FC<PostListProps> = ({
  posts,
  searchQuery,
  onSearchChange,
  selectedCategory,
  onSelectCategory,
  selectedTag,
  onSelectTag,
  onNavigate,
  onDeletePost,
  onLikePost,
  currentUser,
}) => {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState<SortOption>('latest');


  // All unique categories
  const categories = useMemo(() => {
    const cats = new Set<string>();
    posts.forEach((p) => {
      if (p.category) cats.add(p.category);
    });
    return ['Tất cả', ...Array.from(cats)];
  }, [posts]);

  // All unique tags
  const allTags = useMemo(() => {
    const tagsMap = new Map<string, number>();
    posts.forEach((p) => {
      p.tags?.forEach((t) => {
        const count = tagsMap.get(t) || 0;
        tagsMap.set(t, count + 1);
      });
    });
    return Array.from(tagsMap.entries()).sort((a, b) => b[1] - a[1]);
  }, [posts]);

  // Filter and sort posts
  const filteredPosts = useMemo(() => {
    return posts
      .filter((post) => {
        // Category filter
        if (selectedCategory !== 'Tất cả' && post.category !== selectedCategory) {
          return false;
        }
        // Tag filter
        if (selectedTag && !post.tags?.includes(selectedTag)) {
          return false;
        }
        // Search query filter (instant)
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchTitle = post.title.toLowerCase().includes(q);
          const matchContent = post.content.toLowerCase().includes(q);
          const matchCategory = post.category.toLowerCase().includes(q);
          const matchTags = post.tags?.some((t) => t.toLowerCase().includes(q));
          return matchTitle || matchContent || matchCategory || matchTags;
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'latest') {
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        }
        if (sortBy === 'oldest') {
          return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
        }
        if (sortBy === 'views') {
          return b.views - a.views;
        }
        if (sortBy === 'likes') {
          return b.likes - a.likes;
        }
        return 0;
      });
  }, [posts, selectedCategory, selectedTag, searchQuery, sortBy]);

  const totalViews = posts.reduce((acc, p) => acc + p.views, 0);
  const totalLikes = posts.reduce((acc, p) => acc + p.likes, 0);

  const clearAllFilters = () => {
    onSearchChange('');
    onSelectCategory('Tất cả');
    onSelectTag('');
  };

  const hasActiveFilters = searchQuery || selectedCategory !== 'Tất cả' || selectedTag;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Admin Mode Special Banner */}
      {currentUser.role === 'admin' ? (
        <div className="mb-6 p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-black flex-shrink-0 shadow-md">
              👑
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-amber-900 dark:text-amber-300">
                  Chế độ Quản trị viên (Admin)
                </span>
                <span className="text-[10px] bg-amber-500/20 text-amber-700 dark:text-amber-400 font-bold px-2 py-0.5 rounded-full uppercase border border-amber-500/40">
                  Full Access
                </span>
              </div>
              <p className="text-xs text-amber-800/80 dark:text-amber-300/80">
                Bạn có toàn quyền kiểm duyệt mọi bài viết, quản lý danh sách người dùng và cấp/hạ quyền thành viên.
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigate('users-management')}
            className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5 flex-shrink-0"
          >
            <ShieldCheck className="w-4 h-4" />
            Mở Quản lý người dùng
          </button>
        </div>
      ) : (
        <div className="mb-6 p-3.5 rounded-2xl bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-200/60 dark:border-indigo-800/50 flex items-center justify-between">
          <div className="flex items-center gap-2.5 text-xs text-slate-600 dark:text-slate-300">
            <span className="text-base">👋</span>
            <span>Xin chào, <strong className="text-indigo-600 dark:text-indigo-400">{currentUser.name}</strong> (Tài khoản người dùng chuẩn). Bạn có thể đăng bài viết mới và chỉnh sửa các bài do chính mình tạo.</span>
          </div>
        </div>
      )}

      {/* Hero / Quick Bar - Sleek Theme */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 text-white mb-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-semibold tracking-wide uppercase mb-3">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span>Flask 3.0 • SQLite • Markdown Studio</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              Nền tảng chia sẻ bài viết kỹ thuật & lập trình
            </h1>
            <p className="mt-2 text-sm sm:text-base text-slate-400 leading-relaxed">
              Trình soạn thảo Markdown trực quan, API tìm kiếm bài viết tức thì theo thời gian thực và đồng bộ cơ sở dữ liệu SQLite tốc độ cao.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <button
              id="hero-create-btn"
              onClick={() => onNavigate('create')}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2.5 rounded-xl font-semibold text-sm shadow-lg shadow-indigo-500/25 transition-all hover:scale-105 active:scale-95"
            >
              <PlusCircle className="w-4 h-4" />
              Viết bài mới
            </button>
            <button
              id="hero-flask-btn"
              onClick={() => onNavigate('flask-code')}
              className="flex items-center gap-2 bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/80 text-slate-200 px-4 py-2.5 rounded-xl font-medium text-sm transition-all"
            >
              <Code2 className="w-4 h-4 text-indigo-400" />
              Mã nguồn Flask
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* Main Content: Post List (3 columns on lg) */}
        <div className="lg:col-span-3 space-y-6">
          
          {/* Controls Bar: Categories, Sort & View Mode */}
          <div className="bg-white dark:bg-slate-900/60 p-4 sm:p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
            
            {/* Top row: Section title & Real-time pulse indicator */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white tracking-tight">
                  {selectedCategory === 'Tất cả' ? 'Bài viết mới nhất' : `Chuyên mục: ${selectedCategory}`}
                </h2>
                <span className="text-xs bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 font-semibold px-2.5 py-0.5 rounded-full border border-slate-200 dark:border-slate-700">
                  {filteredPosts.length}
                </span>
              </div>

              <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800/80 border border-slate-200/60 dark:border-slate-700/60 py-1 px-3 rounded-full">
                <span className="w-2 h-2 bg-indigo-500 rounded-full animate-pulse"></span>
                <span>Theo thời gian thực</span>
              </div>
            </div>

            {/* Category Pills */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => onSelectCategory(cat)}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                    selectedCategory === cat
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/25 scale-105'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Filter Indicators & View Mode */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100 dark:border-slate-800/80 text-xs">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-slate-500 dark:text-slate-400 font-medium">
                  Hiển thị: <strong className="text-slate-800 dark:text-slate-200">{filteredPosts.length}</strong> bài viết
                </span>

                {hasActiveFilters && (
                  <button
                    onClick={clearAllFilters}
                    className="inline-flex items-center gap-1 text-rose-600 dark:text-rose-400 hover:underline font-medium ml-2"
                  >
                    <X className="w-3.5 h-3.5" />
                    Xóa tất cả bộ lọc
                  </button>
                )}
              </div>

              <div className="flex items-center gap-2">
                {/* Sort Selector */}
                <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl p-1 border border-slate-200/60 dark:border-slate-700/60">
                  <button
                    onClick={() => setSortBy('latest')}
                    className={`px-2.5 py-1 rounded-lg text-xs transition-colors ${
                      sortBy === 'latest' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 font-bold shadow-xs' : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-300'
                    }`}
                    title="Mới nhất"
                  >
                    Mới nhất
                  </button>
                  <button
                    onClick={() => setSortBy('views')}
                    className={`px-2.5 py-1 rounded-lg text-xs transition-colors ${
                      sortBy === 'views' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 font-bold shadow-xs' : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-300'
                    }`}
                    title="Xem nhiều"
                  >
                    Xem nhiều
                  </button>
                  <button
                    onClick={() => setSortBy('likes')}
                    className={`px-2.5 py-1 rounded-lg text-xs transition-colors ${
                      sortBy === 'likes' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 font-bold shadow-xs' : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-300'
                    }`}
                    title="Yêu thích"
                  >
                    Yêu thích
                  </button>
                </div>

                {/* View Mode Buttons */}
                <div className="flex items-center bg-slate-100 dark:bg-slate-800/80 rounded-xl p-1 border border-slate-200/60 dark:border-slate-700/60">
                  <button
                    onClick={() => setViewMode('grid')}
                    className={`p-1.5 rounded-lg transition-colors ${
                      viewMode === 'grid' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs' : 'text-slate-400'
                    }`}
                    title="Dạng lưới"
                  >
                    <LayoutGrid className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setViewMode('list')}
                    className={`p-1.5 rounded-lg transition-colors ${
                      viewMode === 'list' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs' : 'text-slate-400'
                    }`}
                    title="Dạng danh sách"
                  >
                    <List className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Active Tag or Search query badge */}
            {(selectedTag || searchQuery) && (
              <div className="flex items-center gap-2 flex-wrap pt-2 border-t border-slate-100 dark:border-slate-800/60">
                {selectedTag && (
                  <span className="inline-flex items-center gap-1 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 text-xs px-3 py-1 rounded-full font-medium">
                    <Tag className="w-3 h-3" />
                    Thẻ: #{selectedTag}
                    <button onClick={() => onSelectTag('')} className="hover:text-indigo-800 dark:hover:text-indigo-200 ml-1">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                )}
                {searchQuery && (
                  <span className="inline-flex items-center gap-1 bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 text-xs px-3 py-1 rounded-full font-medium">
                    <Search className="w-3 h-3" />
                    Tìm kiếm: "{searchQuery}"
                    <button onClick={() => onSearchChange('')} className="hover:text-amber-800 dark:hover:text-amber-200 ml-1">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                )}
              </div>
            )}
          </div>

          {/* Posts Grid / List */}
          {filteredPosts.length > 0 ? (
            <div className={viewMode === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 gap-6' : 'flex flex-col gap-4'}>
              {filteredPosts.map((post) => (
                <PostCard
                  key={post.id}
                  post={post}
                  searchQuery={searchQuery}
                  onRead={(id) => onNavigate('post-detail', id)}
                  onEdit={(id) => onNavigate('edit', id)}
                  onDelete={onDeletePost}
                  onLike={onLikePost}
                  onTagClick={onSelectTag}
                  onCategoryClick={onSelectCategory}
                  viewMode={viewMode}
                  currentUser={currentUser}
                />
              ))}
            </div>
          ) : (
            /* Empty State */
            <div className="bg-white dark:bg-slate-900/60 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-12 text-center shadow-xs">
              <div className="w-16 h-16 rounded-2xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mx-auto mb-4 border border-indigo-200 dark:border-indigo-800/60">
                <Search className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">
                Không tìm thấy bài viết nào
              </h3>
              <p className="text-sm text-slate-500 dark:text-slate-400 max-w-md mx-auto mb-6">
                {hasActiveFilters 
                  ? 'Thử thay đổi từ khóa tìm kiếm hoặc xóa các bộ lọc danh mục và thẻ tag.'
                  : 'Hãy bắt đầu tạo bài viết đầu tiên của bạn bằng trình soạn thảo Markdown!'}
              </p>
              <div className="flex items-center justify-center gap-3">
                {hasActiveFilters ? (
                  <button
                    onClick={clearAllFilters}
                    className="px-4 py-2 text-sm font-semibold rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700"
                  >
                    Xóa tất cả bộ lọc
                  </button>
                ) : null}
                <button
                  onClick={() => onNavigate('create')}
                  className="px-4 py-2 text-sm font-bold rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-500/20"
                >
                  <PlusCircle className="w-4 h-4 inline mr-1" />
                  Tạo bài viết mới
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Sidebar: Widgets & Tags & Quick Info (1 column on lg) */}
        <div className="space-y-6">
          
          {/* SQLite Engine Live Database Status Card (Sleek Theme feature) */}
          <div className="bg-white dark:bg-slate-900/60 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
            <div className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-3 flex items-center justify-between">
              <span>Cơ sở dữ liệu</span>
              <Database className="w-3.5 h-3.5 text-indigo-500" />
            </div>

            <div className="p-3.5 bg-slate-50 dark:bg-slate-950/80 rounded-xl border border-slate-200/70 dark:border-slate-800">
              <div className="flex items-center justify-between mb-2 text-xs">
                <span className="font-semibold text-slate-700 dark:text-slate-300">SQLite Engine</span>
                <span className="text-emerald-500 dark:text-green-400 flex items-center gap-1.5 font-bold text-[11px]">
                  <span className="w-2 h-2 bg-emerald-500 dark:bg-green-400 rounded-full animate-pulse"></span>
                  Online
                </span>
              </div>
              <div className="w-full bg-slate-200 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden">
                <div className="bg-indigo-500 w-3/4 h-full rounded-full"></div>
              </div>
              <div className="mt-2.5 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                <span>Bộ nhớ sử dụng</span>
                <span className="text-slate-700 dark:text-slate-300 font-semibold">842 / 1024 MB</span>
              </div>
            </div>
          </div>

          {/* Quick Stats Card */}
          <div className="bg-white dark:bg-slate-900/60 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
            <div className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-3 flex items-center gap-2">
              <TrendingUp className="w-3.5 h-3.5 text-indigo-500" />
              <span>Thống kê hệ thống</span>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-slate-50 dark:bg-slate-950/80 p-3 rounded-xl border border-slate-200/60 dark:border-slate-800/80">
                <div className="text-xs text-slate-500 dark:text-slate-400">Tổng bài viết</div>
                <div className="text-xl font-extrabold text-indigo-600 dark:text-indigo-400 mt-1">{posts.length}</div>
              </div>
              <div className="bg-slate-50 dark:bg-slate-950/80 p-3 rounded-xl border border-slate-200/60 dark:border-slate-800/80">
                <div className="text-xs text-slate-500 dark:text-slate-400">Chuyên mục</div>
                <div className="text-xl font-extrabold text-indigo-600 dark:text-indigo-400 mt-1">{categories.length - 1}</div>
              </div>
              <div className="bg-slate-50 dark:bg-slate-950/80 p-3 rounded-xl border border-slate-200/60 dark:border-slate-800/80">
                <div className="text-xs text-slate-500 dark:text-slate-400">Lượt xem</div>
                <div className="text-xl font-extrabold text-emerald-600 dark:text-emerald-400 mt-1">{totalViews}</div>
              </div>
              <div className="bg-slate-50 dark:bg-slate-950/80 p-3 rounded-xl border border-slate-200/60 dark:border-slate-800/80">
                <div className="text-xs text-slate-500 dark:text-slate-400">Yêu thích</div>
                <div className="text-xl font-extrabold text-rose-500 dark:text-rose-400 mt-1">{totalLikes}</div>
              </div>
            </div>
          </div>

          {/* Popular Tags Cloud */}
          {allTags.length > 0 && (
            <div className="bg-white dark:bg-slate-900/60 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
              <div className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                <Tag className="w-3.5 h-3.5 text-indigo-500" />
                <span>Thẻ phổ biến</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {allTags.map(([tag, count]) => (
                  <button
                    key={tag}
                    onClick={() => onSelectTag(selectedTag === tag ? '' : tag)}
                    className={`text-xs px-2.5 py-1 rounded-lg transition-all flex items-center gap-1 font-medium ${
                      selectedTag === tag
                        ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-indigo-50 hover:text-indigo-600 dark:hover:bg-indigo-950/60 dark:hover:text-indigo-300'
                    }`}
                  >
                    <span>#{tag}</span>
                    <span className="text-[10px] opacity-75">({count})</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Python Flask Backend Architecture Card */}
          <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-lg">
            <div className="flex items-center gap-2 text-indigo-400 font-bold text-sm mb-2">
              <Code2 className="w-4 h-4 text-indigo-400" />
              Kiến trúc Python Flask + SQLite
            </div>
            <p className="text-xs text-slate-400 leading-relaxed mb-4">
              Khởi chạy cục bộ chỉ với 2 dòng lệnh terminal chuẩn:
            </p>
            <div className="bg-slate-950 text-slate-100 p-3 rounded-xl text-xs font-mono mb-4 border border-slate-800">
              <span className="text-emerald-400">$</span> pip install -r requirements.txt<br/>
              <span className="text-emerald-400">$</span> python app.py
            </div>
            <button
              onClick={() => onNavigate('flask-code')}
              className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl transition-all shadow-md shadow-indigo-500/20 flex items-center justify-center gap-1.5"
            >
              <Code2 className="w-3.5 h-3.5" />
              Xem mã nguồn & Tải về
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
