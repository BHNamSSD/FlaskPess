import { FlaskProjectFile } from '../types';

export const PYTHON_FLASK_PROJECT: FlaskProjectFile[] = [
  {
    name: 'app.py',
    path: 'app.py',
    language: 'python',
    description: 'Entry point chính của ứng dụng Flask, chứa các route CRUD, API Live Search và middleware.',
    content: `"""
Flask Blog Platform với SQLite, Markdown Editor và Real-time Instant Search
Tác giả: Python Blog Team
"""

import os
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, abort
from database import get_db_connection, init_db
import markdown2
import bleach

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'flask-blog-secret-key-2026')
app.config['DATABASE'] = 'blog.db'

# Khởi tạo CSDL nếu chưa tồn tại
with app.app_context():
    init_db()

# Allowed HTML tags for sanitizing rendered markdown
ALLOWED_TAGS = [
    'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'a', 'b', 'i', 'strong', 'em',
    'ul', 'ol', 'li', 'code', 'pre', 'blockquote', 'hr', 'br', 'img', 'table',
    'thead', 'tbody', 'tr', 'th', 'td', 'input', 'span', 'div'
]
ALLOWED_ATTRIBUTES = {
    '*': ['class', 'id'],
    'a': ['href', 'title', 'target'],
    'img': ['src', 'alt', 'title', 'width', 'height'],
    'input': ['type', 'checked', 'disabled']
}

def render_markdown_safe(md_content):
    """Chuyển đổi Markdown thành HTML an toàn chống XSS"""
    html = markdown2.markdown(md_content or '', extras=[
        'fenced-code-blocks', 'tables', 'strike', 'task_list', 'header-ids', 'code-friendly'
    ])
    cleaned_html = bleach.clean(html, tags=ALLOWED_TAGS, attributes=ALLOWED_ATTRIBUTES)
    return cleaned_html

# Đăng ký custom filter cho template Jinja2
app.jinja_env.filters['markdown'] = render_markdown_safe

# ==================== CÁC ROUTE GIAO DIỆN CHÍNH ====================

@app.route('/')
def index():
    """Trang chủ hiển thị danh sách bài viết thời gian thực"""
    category = request.args.get('category')
    conn = get_db_connection()
    
    if category:
        posts = conn.execute(
            'SELECT * FROM posts WHERE category = ? ORDER BY created_at DESC', (category,)
        ).fetchall()
    else:
        posts = conn.execute(
            'SELECT * FROM posts ORDER BY created_at DESC'
        ).fetchall()
        
    categories = conn.execute(
        'SELECT DISTINCT category FROM posts WHERE category IS NOT NULL AND category != ""'
    ).fetchall()
    
    conn.close()
    return render_template('index.html', posts=posts, categories=categories, selected_category=category)

@app.route('/post/<int:post_id>')
def post_detail(post_id):
    """Xem chi tiết bài viết với Markdown và bình luận"""
    conn = get_db_connection()
    post = conn.execute('SELECT * FROM posts WHERE id = ?', (post_id,)).fetchone()
    
    if post is None:
        conn.close()
        abort(404)
        
    # Tăng lượt xem
    conn.execute('UPDATE posts SET views = views + 1 WHERE id = ?', (post_id,))
    conn.commit()
    
    # Lấy danh sách bình luận
    comments = conn.execute(
        'SELECT * FROM comments WHERE post_id = ? ORDER BY created_at DESC', (post_id,)
    ).fetchall()
    
    conn.close()
    return render_template('post_detail.html', post=post, comments=comments)

@app.route('/create', methods=('GET', 'POST'))
def create_post():
    """Tạo bài viết mới với Markdown Editor"""
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        content = request.form.get('content', '').strip()
        excerpt = request.form.get('excerpt', '').strip()
        category = request.form.get('category', '').strip() or 'Chung'
        tags = request.form.get('tags', '').strip()
        cover_image = request.form.get('cover_image', '').strip()
        author_name = request.form.get('author_name', 'Tác giả').strip()

        if not title:
            flash('Vui lòng nhập tiêu đề bài viết!', 'danger')
        elif not content:
            flash('Vui lòng nhập nội dung bài viết!', 'danger')
        else:
            if not excerpt:
                # Tự động tạo tóm tắt ngắn từ nội dung
                clean_preview = content.replace('#', '').replace('*', '').replace('\`', '')
                excerpt = clean_preview[:160] + '...' if len(clean_preview) > 160 else clean_preview

            conn = get_db_connection()
            conn.execute(
                '''INSERT INTO posts (title, content, excerpt, category, tags, cover_image, author_name)
                   VALUES (?, ?, ?, ?, ?, ?, ?)''',
                (title, content, excerpt, category, tags, cover_image, author_name)
            )
            conn.commit()
            conn.close()
            flash('Đăng bài viết thành công!', 'success')
            return redirect(url_for('index'))

    return render_template('create_post.html')

@app.route('/edit/<int:post_id>', methods=('GET', 'POST'))
def edit_post(post_id):
    """Chỉnh sửa bài viết hiện có"""
    conn = get_db_connection()
    post = conn.execute('SELECT * FROM posts WHERE id = ?', (post_id,)).fetchone()
    
    if post is None:
        conn.close()
        abort(404)

    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        content = request.form.get('content', '').strip()
        excerpt = request.form.get('excerpt', '').strip()
        category = request.form.get('category', '').strip() or 'Chung'
        tags = request.form.get('tags', '').strip()
        cover_image = request.form.get('cover_image', '').strip()

        if not title or not content:
            flash('Tiêu đề và nội dung không được để trống!', 'danger')
        else:
            conn.execute(
                '''UPDATE posts 
                   SET title = ?, content = ?, excerpt = ?, category = ?, tags = ?, cover_image = ?, updated_at = CURRENT_TIMESTAMP
                   WHERE id = ?''',
                (title, content, excerpt, category, tags, cover_image, post_id)
            )
            conn.commit()
            conn.close()
            flash('Cập nhật bài viết thành công!', 'success')
            return redirect(url_for('post_detail', post_id=post_id))

    conn.close()
    return render_template('edit_post.html', post=post)

@app.route('/delete/<int:post_id>', methods=('POST',))
def delete_post(post_id):
    """Xóa bài viết an toàn qua POST request"""
    conn = get_db_connection()
    conn.execute('DELETE FROM comments WHERE post_id = ?', (post_id,))
    conn.execute('DELETE FROM posts WHERE id = ?', (post_id,))
    conn.commit()
    conn.close()
    flash('Đã xóa bài viết thành công!', 'info')
    return redirect(url_for('index'))

@app.route('/post/<int:post_id>/comment', methods=('POST',))
def add_comment(post_id):
    """Thêm bình luận mới cho bài viết"""
    author = request.form.get('author', 'Bạn đọc ẩn danh').strip()
    content = request.form.get('content', '').strip()
    
    if content:
        conn = get_db_connection()
        conn.execute(
            'INSERT INTO comments (post_id, author, content) VALUES (?, ?, ?)',
            (post_id, author, content)
        )
        conn.commit()
        conn.close()
        flash('Đã gửi bình luận!', 'success')
    return redirect(url_for('post_detail', post_id=post_id))

# ==================== API REAL-TIME INSTANT SEARCH ====================

@app.route('/api/search')
def api_search():
    """API tìm kiếm tức thì theo thời gian thực (Real-time Instant Search)"""
    query = request.args.get('q', '').strip()
    if not query:
        return jsonify([])
        
    search_pattern = f'%{query}%'
    conn = get_db_connection()
    posts = conn.execute(
        '''SELECT id, title, excerpt, category, tags, created_at, cover_image 
           FROM posts 
           WHERE title LIKE ? OR content LIKE ? OR tags LIKE ? OR category LIKE ?
           ORDER BY created_at DESC LIMIT 8''',
        (search_pattern, search_pattern, search_pattern, search_pattern)
    ).fetchall()
    conn.close()
    
    results = [dict(post) for post in posts]
    return jsonify(results)

if __name__ == '__main__':
    # Chạy server ở chế độ debug port 5000
    app.run(host='0.0.0.0', port=5000, debug=True)
`
  },
  {
    name: 'database.py',
    path: 'database.py',
    language: 'python',
    description: 'Module kết nối và khởi tạo cơ sở dữ liệu SQLite với cấu trúc schema chuẩn.',
    content: `"""
Module quản lý cơ sở dữ liệu SQLite cho ứng dụng Blog Flask
"""

import sqlite3
import os

DB_FILE = 'blog.db'

def get_db_connection():
    """Tạo kết nối tới SQLite và trả về đối tượng kết nối với row_factory dạng dict"""
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Khởi tạo các bảng và chèn dữ liệu mẫu ban đầu"""
    conn = get_db_connection()
    with open('schema.sql', 'r', encoding='utf-8') as f:
        conn.executescript(f.read())
    
    # Kiểm tra xem đã có bài viết mẫu chưa, nếu chưa thì thêm vào
    cur = conn.cursor()
    cur.execute('SELECT COUNT(*) FROM posts')
    count = cur.fetchone()[0]
    
    if count == 0:
        cur.execute('''
            INSERT INTO posts (title, excerpt, content, category, tags, author_name, cover_image)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            'Chào mừng đến với Blog Python Flask & SQLite',
            'Hướng dẫn cài đặt và sử dụng blog với đầy đủ tính năng Markdown, Dark mode và tìm kiếm tức thì.',
            '''# Chào mừng bạn đến với Blog!

Đây là bài viết mẫu đầu tiên được lưu trữ trong **SQLite** và hiển thị bằng **Markdown**.

## Các tính năng nổi bật:
- [x] Soạn thảo Markdown trực quan với Live Preview
- [x] Tìm kiếm bài viết tức thì (Instant Live Search)
- [x] Chế độ sáng / tối (Dark Mode) lưu vào \`localStorage\`
- [x] Tối ưu hóa giao diện Bootstrap 5 trên điện thoại di động
- [x] Đăng, sửa, xóa bài viết dễ dàng

\`\`\`python
# Chạy ứng dụng nhanh chóng:
python app.py
\`\`\`

Chúc bạn có trải nghiệm viết blog tuyệt vời!''',
            'Hướng dẫn',
            'Flask, SQLite, Markdown',
            'Admin',
            'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=1200&q=80'
        ))
        conn.commit()
        
    conn.close()
    print("✓ Cơ sở dữ liệu SQLite đã được khởi tạo thành công.")
`
  },
  {
    name: 'schema.sql',
    path: 'schema.sql',
    language: 'sql',
    description: 'Cấu trúc định nghĩa bảng dữ liệu SQLite (posts, comments, categories).',
    content: `-- Schema cơ sở dữ liệu SQLite cho Blog Flask
DROP TABLE IF EXISTS comments;
DROP TABLE IF EXISTS posts;

-- Bảng quản lý bài viết (Posts)
CREATE TABLE posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    slug TEXT,
    excerpt TEXT,
    content TEXT NOT NULL,
    category TEXT DEFAULT 'Chung',
    tags TEXT,
    cover_image TEXT,
    author_name TEXT DEFAULT 'Admin',
    views INTEGER DEFAULT 0,
    likes INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Bảng quản lý bình luận (Comments)
CREATE TABLE comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id INTEGER NOT NULL,
    author TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (post_id) REFERENCES posts (id) ON DELETE CASCADE
);

-- Chỉ mục tối ưu hóa tìm kiếm nhanh
CREATE INDEX idx_posts_title ON posts(title);
CREATE INDEX idx_posts_category ON posts(category);
CREATE INDEX idx_posts_created_at ON posts(created_at);
`
  },
  {
    name: 'templates/base.html',
    path: 'templates/base.html',
    language: 'html',
    description: 'Template gốc sử dụng Bootstrap 5.3, tích hợp Dark Mode toggle, Live Search bar trên đầu trang và layout responsive.',
    content: `<!DOCTYPE html>
<html lang="vi" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}Python Flask Blog{% endblock %}</title>
    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="{{ url_for('static', filename='css/style.css') }}">
    <script>
        // Khởi tạo Dark Mode ngay từ đầu để tránh chớp màn hình (FOUC)
        (function() {
            const savedTheme = localStorage.getItem('flask_blog_theme') || 
                (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
            document.documentElement.setAttribute('data-bs-theme', savedTheme);
        })();
    </script>
</head>
<body>

    <!-- Header & Navigation Bar -->
    <header class="sticky-top bg-body shadow-sm">
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <!-- Logo & Brand -->
                <a class="navbar-brand fw-bold d-flex align-items-center gap-2" href="{{ url_for('index') }}">
                    <span class="brand-icon"><i class="bi bi-journal-code text-primary"></i></span>
                    <span>Flask<span class="text-primary">Blog</span></span>
                </a>

                <!-- Mobile Menu & Search Toggle -->
                <div class="d-flex align-items-center gap-2 d-lg-none">
                    <button class="btn btn-outline-secondary btn-sm" id="theme-toggle-mobile" aria-label="Toggle Theme">
                        <i class="bi bi-moon-stars"></i>
                    </button>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                </div>

                <!-- Navbar Collapse -->
                <div class="collapse navbar-collapse" id="navbarContent">
                    <!-- Instant Live Search Bar trên cùng -->
                    <div class="mx-auto my-2 my-lg-0 search-container position-relative flex-grow-1 max-w-500">
                        <div class="input-group">
                            <span class="input-group-text bg-transparent border-end-0 text-muted">
                                <i class="bi bi-search"></i>
                            </span>
                            <input type="search" id="top-live-search" class="form-control border-start-0 ps-0" 
                                   placeholder="Tìm kiếm bài viết tức thì theo từ khóa, danh mục..." 
                                   autocomplete="off">
                            <span class="input-group-text bg-transparent text-muted small d-none d-md-inline" id="search-spinner" style="display: none !important;">
                                <div class="spinner-border spinner-border-sm text-primary" role="status"></div>
                            </span>
                        </div>

                        <!-- Dropdown kết quả tìm kiếm thời gian thực -->
                        <div id="search-dropdown-results" class="search-dropdown card shadow-lg position-absolute w-100 mt-1 d-none z-3">
                            <div class="list-group list-group-flush" id="search-results-list"></div>
                        </div>
                    </div>

                    <!-- Right Navigation Links & Actions -->
                    <ul class="navbar-nav align-items-lg-center gap-2 ms-lg-3">
                        <li class="nav-item">
                            <a class="nav-link" href="{{ url_for('index') }}"><i class="bi bi-house me-1"></i>Trang chủ</a>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-primary btn-sm d-flex align-items-center gap-1" href="{{ url_for('create_post') }}">
                                <i class="bi bi-pencil-square"></i> Đăng bài viết
                            </a>
                        </li>
                        <!-- Desktop Dark Mode Toggle Button -->
                        <li class="nav-item d-none d-lg-block">
                            <button class="btn btn-outline-secondary btn-sm" id="theme-toggle-desktop" title="Chuyển đổi giao diện Sáng / Tối">
                                <i class="bi bi-moon-stars" id="theme-icon"></i>
                            </button>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <!-- Flash Messages (Thông báo) -->
    <div class="container mt-3">
        {% with messages = get_flashed_messages(with_categories=true) %}
            {% if messages %}
                {% for category, message in messages %}
                    <div class="alert alert-{{ category }} alert-dismissible fade show" role="alert">
                        {{ message }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                {% endfor %}
            {% endif %}
        {% endwith %}
    </div>

    <!-- Main Page Content -->
    <main class="container py-4">
        {% block content %}{% endblock %}
    </main>

    <!-- Footer -->
    <footer class="bg-body-tertiary border-top py-4 mt-5">
        <div class="container text-center text-muted small">
            <p class="mb-1">© 2026 Flask Blog System • Xây dựng với Python Flask, SQLite & Bootstrap 5</p>
            <p class="mb-0">Hỗ trợ Markdown Editor • Instant Live Search • Dark Mode LocalStorage</p>
        </div>
    </footer>

    <!-- Bootstrap 5.3 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JS -->
    <script src="{{ url_for('static', filename='js/app.js') }}"></script>
    {% block scripts %}{% endblock %}
</body>
</html>
`
  },
  {
    name: 'templates/index.html',
    path: 'templates/index.html',
    language: 'html',
    description: 'Trang danh sách bài viết thời gian thực với phân loại theo chuyên mục, thẻ tag và giao diện thẻ bài đẹp mắt.',
    content: `{% extends 'base.html' %}

{% block title %}Trang chủ - Flask Blog{% endblock %}

{% block content %}
<div class="row g-4">
    <!-- Cột bên trái: Danh sách bài viết -->
    <div class="col-lg-8">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1 class="h4 mb-0 fw-bold">
                {% if selected_category %}
                    Chuyên mục: <span class="text-primary">{{ selected_category }}</span>
                {% else %}
                    Tất cả bài viết mới nhất
                {% endif %}
            </h1>
            <span class="badge bg-secondary-subtle text-secondary fs-6">{{ posts|length }} bài viết</span>
        </div>

        {% if posts %}
            <div class="d-flex flex-column gap-3">
                {% for post in posts %}
                    <article class="card blog-card shadow-sm border-0 transition-hover">
                        <div class="row g-0 align-items-center">
                            {% if post['cover_image'] %}
                                <div class="col-md-4">
                                    <img src="{{ post['cover_image'] }}" class="img-fluid rounded-start blog-card-img h-100 object-fit-cover" alt="{{ post['title'] }}">
                                </div>
                            {% endif %}
                            <div class="col-md-{{ '8' if post['cover_image'] else '12' }}">
                                <div class="card-body">
                                    <div class="d-flex align-items-center gap-2 mb-2">
                                        <span class="badge bg-primary-subtle text-primary">{{ post['category'] or 'Chung' }}</span>
                                        <small class="text-muted"><i class="bi bi-clock me-1"></i>{{ post['created_at'][:10] }}</small>
                                        <small class="text-muted ms-auto"><i class="bi bi-eye me-1"></i>{{ post['views'] or 0 }}</small>
                                    </div>
                                    <h2 class="card-title h5 fw-bold">
                                        <a href="{{ url_for('post_detail', post_id=post['id']) }}" class="text-decoration-none text-body">
                                            {{ post['title'] }}
                                        </a>
                                    </h2>
                                    <p class="card-text text-muted small line-clamp-2">
                                        {{ post['excerpt'] or 'Nhấn để đọc chi tiết nội dung...' }}
                                    </p>
                                    <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                                        <small class="text-muted fw-medium"><i class="bi bi-person me-1"></i>{{ post['author_name'] or 'Admin' }}</small>
                                        <a href="{{ url_for('post_detail', post_id=post['id']) }}" class="btn btn-sm btn-outline-primary">
                                            Đọc tiếp <i class="bi bi-arrow-right"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </article>
                {% endfor %}
            </div>
        {% else %}
            <div class="card p-5 text-center shadow-sm">
                <i class="bi bi-inbox text-muted display-4 mb-3"></i>
                <h5>Chưa có bài viết nào trong mục này</h5>
                <p class="text-muted">Hãy là người đầu tiên đăng tải bài viết mới!</p>
                <div>
                    <a href="{{ url_for('create_post') }}" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i>Viết bài ngay</a>
                </div>
            </div>
        {% endif %}
    </div>

    <!-- Cột bên phải: Danh mục & Tiện ích -->
    <div class="col-lg-4">
        <!-- Widget Chuyên mục -->
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-header bg-transparent fw-bold"><i class="bi bi-folder me-2 text-primary"></i>Danh mục</div>
            <div class="list-group list-group-flush">
                <a href="{{ url_for('index') }}" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center {{ 'active' if not selected_category else '' }}">
                    Tất cả danh mục
                </a>
                {% for cat in categories %}
                    <a href="{{ url_for('index', category=cat['category']) }}" 
                       class="list-group-item list-group-item-action d-flex justify-content-between align-items-center {{ 'active' if selected_category == cat['category'] else '' }}">
                        {{ cat['category'] }}
                    </a>
                {% endfor %}
            </div>
        </div>

        <!-- Widget Giới thiệu Flask Blog -->
        <div class="card shadow-sm border-0 bg-primary-subtle text-primary-emphasis">
            <div class="card-body">
                <h6 class="fw-bold"><i class="bi bi-info-circle me-1"></i> Về Flask Blog Studio</h6>
                <p class="small mb-0">Hệ thống blog chạy trên nền tảng Python Flask và SQLite cực kỳ nhanh, hỗ trợ đầy đủ Markdown, tìm kiếm theo thời gian thực và tự động đồng bộ chế độ Dark Mode.</p>
            </div>
        </div>
    </div>
</div>
{% endblock %}
`
  },
  {
    name: 'templates/post_detail.html',
    path: 'templates/post_detail.html',
    language: 'html',
    description: 'Trang chi tiết bài viết hiển thị nội dung Markdown được định dạng chuẩn, các nút sửa/xóa và phần bình luận.',
    content: `{% extends 'base.html' %}

{% block title %}{{ post['title'] }} - Flask Blog{% endblock %}

{% block content %}
<div class="row justify-content-center">
    <div class="col-lg-9">
        <!-- Nút quay lại -->
        <div class="mb-3">
            <a href="{{ url_for('index') }}" class="text-decoration-none text-muted small">
                <i class="bi bi-arrow-left me-1"></i> Quay lại danh sách
            </a>
        </div>

        <!-- Thẻ bài viết chi tiết -->
        <article class="card shadow-sm border-0 mb-4">
            {% if post['cover_image'] %}
                <img src="{{ post['cover_image'] }}" class="card-img-top max-h-400 object-fit-cover" alt="{{ post['title'] }}">
            {% endif %}
            
            <div class="card-body p-md-5">
                <!-- Meta Info -->
                <div class="d-flex flex-wrap align-items-center gap-2 mb-3">
                    <span class="badge bg-primary-subtle text-primary px-3 py-2">{{ post['category'] or 'Chung' }}</span>
                    <span class="text-muted small"><i class="bi bi-calendar3 me-1"></i>{{ post['created_at'][:10] }}</span>
                    <span class="text-muted small"><i class="bi bi-eye me-1"></i>{{ post['views'] }} lượt xem</span>
                </div>

                <!-- Tiêu đề bài viết -->
                <h1 class="display-6 fw-bold mb-4">{{ post['title'] }}</h1>

                <!-- Thông tin tác giả & Thao tác Quản lý -->
                <div class="d-flex justify-content-between align-items-center pb-4 mb-4 border-bottom">
                    <div class="d-flex align-items-center gap-3">
                        <div class="avatar bg-primary text-white rounded-circle d-flex align-items-center justify-content-center fw-bold" style="width: 42px; height: 42px;">
                            {{ post['author_name'][:1] | upper }}
                        </div>
                        <div>
                            <div class="fw-bold">{{ post['author_name'] or 'Admin' }}</div>
                            <small class="text-muted">Tác giả bài viết</small>
                        </div>
                    </div>

                    <!-- Nút Chỉnh sửa & Xóa bài viết -->
                    <div class="d-flex gap-2">
                        <a href="{{ url_for('edit_post', post_id=post['id']) }}" class="btn btn-outline-secondary btn-sm">
                            <i class="bi bi-pencil me-1"></i> Sửa
                        </a>
                        <form action="{{ url_for('delete_post', post_id=post['id']) }}" method="POST" onsubmit="return confirm('Bạn có chắc chắn muốn xóa bài viết này không?');">
                            <button type="submit" class="btn btn-outline-danger btn-sm">
                                <i class="bi bi-trash me-1"></i> Xóa
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Nội dung Markdown đã Render -->
                <div class="markdown-content">
                    {{ post['content'] | markdown | safe }}
                </div>

                <!-- Thẻ tags nếu có -->
                {% if post['tags'] %}
                    <div class="mt-4 pt-3 border-top d-flex gap-2 align-items-center flex-wrap">
                        <small class="text-muted fw-bold"><i class="bi bi-tags me-1"></i>Tags:</small>
                        {% for tag in post['tags'].split(',') %}
                            {% if tag.strip() %}
                                <span class="badge bg-secondary-subtle text-secondary">#{{ tag.strip() }}</span>
                            {% endif %}
                        {% endfor %}
                    </div>
                {% endif %}
            </div>
        </article>

        <!-- Khu vực bình luận -->
        <section class="card shadow-sm border-0 p-4 mb-4">
            <h4 class="h5 fw-bold mb-3"><i class="bi bi-chat-dots me-2 text-primary"></i>Bình luận ({{ comments|length }})</h4>
            
            <!-- Form gửi bình luận -->
            <form action="{{ url_for('add_comment', post_id=post['id']) }}" method="POST" class="mb-4">
                <div class="row g-2 mb-2">
                    <div class="col-md-6">
                        <input type="text" name="author" class="form-control form-control-sm" placeholder="Họ và tên của bạn" required>
                    </div>
                </div>
                <div class="mb-2">
                    <textarea name="content" class="form-control form-control-sm" rows="3" placeholder="Viết cảm nghĩ hoặc câu hỏi của bạn..." required></textarea>
                </div>
                <button type="submit" class="btn btn-primary btn-sm"><i class="bi bi-send me-1"></i>Gửi bình luận</button>
            </form>

            <!-- Danh sách bình luận -->
            <div class="d-flex flex-column gap-3">
                {% for comment in comments %}
                    <div class="p-3 bg-body-tertiary rounded">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <span class="fw-bold small">{{ comment['author'] }}</span>
                            <span class="text-muted small">{{ comment['created_at'][:16] }}</span>
                        </div>
                        <p class="mb-0 small text-body">{{ comment['content'] }}</p>
                    </div>
                {% else %}
                    <p class="text-muted small mb-0 text-center py-2">Chưa có bình luận nào. Hãy là người đầu tiên chia sẻ ý kiến!</p>
                {% endfor %}
            </div>
        </section>
    </div>
</div>
{% endblock %}
`
  },
  {
    name: 'templates/create_post.html',
    path: 'templates/create_post.html',
    language: 'html',
    description: 'Trang tạo bài viết mới tích hợp thanh công cụ Markdown và Live Preview tức thì.',
    content: `{% extends 'base.html' %}

{% block title %}Đăng bài viết mới - Flask Blog{% endblock %}

{% block content %}
<div class="row justify-content-center">
    <div class="col-lg-10">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 fw-bold mb-0"><i class="bi bi-pencil-square text-primary me-2"></i>Đăng bài viết mới</h1>
            <a href="{{ url_for('index') }}" class="btn btn-outline-secondary btn-sm">Hủy bỏ</a>
        </div>

        <form method="POST" class="card shadow-sm border-0 p-4">
            <!-- Tiêu đề bài viết -->
            <div class="mb-3">
                <label for="title" class="form-label fw-bold">Tiêu đề bài viết <span class="text-danger">*</span></label>
                <input type="text" class="form-control form-control-lg" id="title" name="title" placeholder="Nhập tiêu đề hấp dẫn cho bài viết..." required autofocus>
            </div>

            <div class="row g-3 mb-3">
                <!-- Chuyên mục -->
                <div class="col-md-6">
                    <label for="category" class="form-label fw-bold">Chuyên mục</label>
                    <input type="text" class="form-control" id="category" name="category" placeholder="Ví dụ: Lập trình Python, Công nghệ..." list="category-options">
                    <datalist id="category-options">
                        <option value="Lập trình Python">
                        <option value="Cơ sở dữ liệu SQLite">
                        <option value="Kỹ năng viết">
                        <option value="Giao diện UI/UX">
                    </datalist>
                </div>
                <!-- Thẻ tags -->
                <div class="col-md-6">
                    <label for="tags" class="form-label fw-bold">Thẻ Tags</label>
                    <input type="text" class="form-control" id="tags" name="tags" placeholder="flask, sqlite, markdown (cách nhau bởi dấu phẩy)">
                </div>
            </div>

            <div class="row g-3 mb-3">
                <!-- Ảnh bìa -->
                <div class="col-md-8">
                    <label for="cover_image" class="form-label fw-bold">URL Ảnh bìa (Cover Image)</label>
                    <input type="url" class="form-control" id="cover_image" name="cover_image" placeholder="https://images.unsplash.com/photo-...">
                </div>
                <!-- Tác giả -->
                <div class="col-md-4">
                    <label for="author_name" class="form-label fw-bold">Tác giả</label>
                    <input type="text" class="form-control" id="author_name" name="author_name" value="Admin">
                </div>
            </div>

            <!-- Tóm tắt ngắn -->
            <div class="mb-3">
                <label for="excerpt" class="form-label fw-bold">Tóm tắt ngắn (Excerpt)</label>
                <textarea class="form-control" id="excerpt" name="excerpt" rows="2" placeholder="Tóm tắt ngắn nội dung bài viết hiển thị ở trang chủ..."></textarea>
            </div>

            <!-- Markdown Toolbar & Editor -->
            <div class="mb-4">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <label for="markdown-editor" class="form-label fw-bold mb-0">Nội dung bài viết (Markdown) <span class="text-danger">*</span></label>
                    <div class="btn-group btn-group-sm" role="group">
                        <button type="button" class="btn btn-outline-secondary" onclick="insertMd('**', '**', 'chữ đậm')"><b>B</b></button>
                        <button type="button" class="btn btn-outline-secondary" onclick="insertMd('*', '*', 'chữ nghiêng')"><i>I</i></button>
                        <button type="button" class="btn btn-outline-secondary" onclick="insertMd('# ', '', 'Tiêu đề lớn')">H1</button>
                        <button type="button" class="btn btn-outline-secondary" onclick="insertMd('## ', '', 'Tiêu đề phụ')">H2</button>
                        <button type="button" class="btn btn-outline-secondary" onclick="insertMd('> ', '', 'Trích dẫn')"><i class="bi bi-quote"></i></button>
                        <button type="button" class="btn btn-outline-secondary" onclick="insertMd('\`\`\`python\\n', '\\n\`\`\`', '# mã code ở đây')"><i class="bi bi-code-slash"></i></button>
                        <button type="button" class="btn btn-outline-secondary" onclick="insertMd('- [ ] ', '', 'Công việc')"><i class="bi bi-check2-square"></i></button>
                        <button type="button" class="btn btn-outline-secondary" onclick="insertMd('[', '](https://example.com)', 'Tên liên kết')"><i class="bi bi-link-45deg"></i></button>
                    </div>
                </div>

                <div class="row g-2">
                    <div class="col-md-6">
                        <textarea class="form-control font-monospace" id="markdown-editor" name="content" rows="14" placeholder="# Viết nội dung Markdown tại đây..." required></textarea>
                    </div>
                    <div class="col-md-6">
                        <div class="border rounded p-3 h-100 bg-body-tertiary overflow-auto max-h-400" id="markdown-preview">
                            <p class="text-muted small">Bản xem trước trực tiếp (Live Preview) sẽ hiển thị tại đây...</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Nút gửi -->
            <div class="d-flex justify-content-end gap-2">
                <a href="{{ url_for('index') }}" class="btn btn-secondary">Hủy</a>
                <button type="submit" class="btn btn-primary px-4"><i class="bi bi-check2-circle me-1"></i> Xuất bản bài viết</button>
            </div>
        </form>
    </div>
</div>
{% endblock %}
`
  },
  {
    name: 'templates/edit_post.html',
    path: 'templates/edit_post.html',
    language: 'html',
    description: 'Trang chỉnh sửa bài viết đã có với dữ liệu nạp sẵn và hỗ trợ Markdown Live Preview.',
    content: `{% extends 'base.html' %}

{% block title %}Chỉnh sửa: {{ post['title'] }} - Flask Blog{% endblock %}

{% block content %}
<div class="row justify-content-center">
    <div class="col-lg-10">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 fw-bold mb-0"><i class="bi bi-pencil text-primary me-2"></i>Chỉnh sửa bài viết</h1>
            <a href="{{ url_for('post_detail', post_id=post['id']) }}" class="btn btn-outline-secondary btn-sm">Quay lại bài viết</a>
        </div>

        <form method="POST" class="card shadow-sm border-0 p-4">
            <div class="mb-3">
                <label for="title" class="form-label fw-bold">Tiêu đề bài viết <span class="text-danger">*</span></label>
                <input type="text" class="form-control form-control-lg" id="title" name="title" value="{{ post['title'] }}" required>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-md-6">
                    <label for="category" class="form-label fw-bold">Chuyên mục</label>
                    <input type="text" class="form-control" id="category" name="category" value="{{ post['category'] or '' }}">
                </div>
                <div class="col-md-6">
                    <label for="tags" class="form-label fw-bold">Thẻ Tags</label>
                    <input type="text" class="form-control" id="tags" name="tags" value="{{ post['tags'] or '' }}">
                </div>
            </div>

            <div class="mb-3">
                <label for="cover_image" class="form-label fw-bold">URL Ảnh bìa (Cover Image)</label>
                <input type="url" class="form-control" id="cover_image" name="cover_image" value="{{ post['cover_image'] or '' }}">
            </div>

            <div class="mb-3">
                <label for="excerpt" class="form-label fw-bold">Tóm tắt ngắn (Excerpt)</label>
                <textarea class="form-control" id="excerpt" name="excerpt" rows="2">{{ post['excerpt'] or '' }}</textarea>
            </div>

            <!-- Markdown Editor -->
            <div class="mb-4">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <label for="markdown-editor" class="form-label fw-bold mb-0">Nội dung bài viết (Markdown)</label>
                    <div class="btn-group btn-group-sm" role="group">
                        <button type="button" class="btn btn-outline-secondary" onclick="insertMd('**', '**', 'chữ đậm')"><b>B</b></button>
                        <button type="button" class="btn btn-outline-secondary" onclick="insertMd('*', '*', 'chữ nghiêng')"><i>I</i></button>
                        <button type="button" class="btn btn-outline-secondary" onclick="insertMd('## ', '', 'Tiêu đề')">H2</button>
                        <button type="button" class="btn btn-outline-secondary" onclick="insertMd('> ', '', 'Trích dẫn')"><i class="bi bi-quote"></i></button>
                    </div>
                </div>

                <div class="row g-2">
                    <div class="col-md-6">
                        <textarea class="form-control font-monospace" id="markdown-editor" name="content" rows="14" required>{{ post['content'] }}</textarea>
                    </div>
                    <div class="col-md-6">
                        <div class="border rounded p-3 h-100 bg-body-tertiary overflow-auto max-h-400" id="markdown-preview">
                            <!-- Preview sẽ được cập nhật tự động bằng JS -->
                        </div>
                    </div>
                </div>
            </div>

            <div class="d-flex justify-content-end gap-2">
                <a href="{{ url_for('post_detail', post_id=post['id']) }}" class="btn btn-secondary">Hủy</a>
                <button type="submit" class="btn btn-primary px-4"><i class="bi bi-save me-1"></i> Lưu thay đổi</button>
            </div>
        </form>
    </div>
</div>
{% endblock %}
`
  },
  {
    name: 'static/css/style.css',
    path: 'static/css/style.css',
    language: 'css',
    description: 'Tệp stylesheet tùy biến Bootstrap 5, hiệu ứng chuyển màu Dark Mode và style Markdown.',
    content: `/* Custom Stylesheet cho Flask Blog */

:root {
    --font-sans: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
    --font-mono: 'JetBrains Mono', monospace;
}

body {
    font-family: var(--font-sans);
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

main {
    flex: 1;
}

/* Custom Search Container */
.max-w-500 {
    max-width: 480px;
}

.search-dropdown {
    max-height: 380px;
    overflow-y: auto;
    border-radius: 12px;
}

/* Blog Card Styles */
.blog-card {
    border-radius: 12px;
    overflow: hidden;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.transition-hover:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1) !important;
}

.blog-card-img {
    min-height: 180px;
    max-height: 220px;
}

.max-h-400 {
    max-height: 400px;
}

.line-clamp-2 {
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

/* Markdown Content Styling */
.markdown-content {
    font-size: 1.05rem;
    line-height: 1.8;
}

.markdown-content h1, 
.markdown-content h2, 
.markdown-content h3 {
    font-weight: 700;
    margin-top: 1.5rem;
    margin-bottom: 0.8rem;
}

.markdown-content blockquote {
    border-left: 4px solid var(--bs-primary);
    padding-left: 1rem;
    color: var(--bs-secondary-color);
    font-style: italic;
    margin: 1.5rem 0;
}

.markdown-content pre {
    background-color: var(--bs-tertiary-bg);
    border: 1px solid var(--bs-border-color);
    border-radius: 8px;
    padding: 1rem;
    overflow-x: auto;
    font-family: var(--font-mono);
}

.markdown-content table {
    width: 100%;
    margin: 1.5rem 0;
    border-collapse: collapse;
}

.markdown-content th, .markdown-content td {
    padding: 0.75rem;
    border: 1px solid var(--bs-border-color);
}

.markdown-content th {
    background-color: var(--bs-tertiary-bg);
}
`
  },
  {
    name: 'static/js/app.js',
    path: 'static/js/app.js',
    language: 'javascript',
    description: 'JavaScript xử lý tìm kiếm tức thì Real-time, Dark Mode LocalStorage và Live Markdown Preview.',
    content: `/**
 * JavaScript cho Flask Blog
 * - Quản lý Chế độ Dark Mode qua localStorage
 * - Tìm kiếm bài viết tức thì (Real-time Instant Search)
 * - Markdown Live Preview
 */

document.addEventListener('DOMContentLoaded', () => {
    initThemeToggle();
    initInstantSearch();
    initMarkdownPreview();
});

// 1. Quản lý Dark Mode và lưu vào LocalStorage
function initThemeToggle() {
    const themeKey = 'flask_blog_theme';
    const desktopBtn = document.getElementById('theme-toggle-desktop');
    const mobileBtn = document.getElementById('theme-toggle-mobile');
    const icon = document.getElementById('theme-icon');

    function updateIcon(theme) {
        if (!icon) return;
        if (theme === 'dark') {
            icon.className = 'bi bi-sun-fill text-warning';
        } else {
            icon.className = 'bi bi-moon-stars';
        }
    }

    function toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-bs-theme') || 'light';
        const nextTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        document.documentElement.setAttribute('data-bs-theme', nextTheme);
        localStorage.setItem(themeKey, nextTheme);
        updateIcon(nextTheme);
    }

    // Set initial icon
    const current = document.documentElement.getAttribute('data-bs-theme') || 'light';
    updateIcon(current);

    if (desktopBtn) desktopBtn.addEventListener('click', toggleTheme);
    if (mobileBtn) mobileBtn.addEventListener('click', toggleTheme);
}

// 2. Tìm kiếm tức thì theo thời gian thực (Real-time Instant Search)
function initInstantSearch() {
    const searchInput = document.getElementById('top-live-search');
    const dropdown = document.getElementById('search-dropdown-results');
    const resultsList = document.getElementById('search-results-list');
    const spinner = document.getElementById('search-spinner');

    if (!searchInput || !dropdown || !resultsList) return;

    let debounceTimer;

    searchInput.addEventListener('input', (e) => {
        const query = e.target.value.trim();

        clearTimeout(debounceTimer);

        if (query.length === 0) {
            dropdown.classList.add('d-none');
            if (spinner) spinner.style.setProperty('display', 'none', 'important');
            return;
        }

        if (spinner) spinner.style.setProperty('display', 'inline-block', 'important');

        debounceTimer = setTimeout(async () => {
            try {
                const response = await fetch(\`/api/search?q=\${encodeURIComponent(query)}\`);
                const posts = await response.json();

                renderSearchResults(posts, query);
            } catch (err) {
                console.error('Lỗi tìm kiếm:', err);
            } finally {
                if (spinner) spinner.style.setProperty('display', 'none', 'important');
            }
        }, 250); // debounce 250ms
    });

    function renderSearchResults(posts, query) {
        resultsList.innerHTML = '';

        if (!posts || posts.length === 0) {
            resultsList.innerHTML = \`
                <div class="p-3 text-center text-muted small">
                    <i class="bi bi-search me-1"></i> Không tìm thấy bài viết nào phù hợp với "<strong>\${escapeHtml(query)}</strong>"
                </div>
            \`;
            dropdown.classList.remove('d-none');
            return;
        }

        posts.forEach(post => {
            const item = document.createElement('a');
            item.href = \`/post/\${post.id}\`;
            item.className = 'list-group-item list-group-item-action p-3';
            item.innerHTML = \`
                <div class="d-flex justify-content-between align-items-center mb-1">
                    <span class="badge bg-primary-subtle text-primary small">\${post.category || 'Chung'}</span>
                    <small class="text-muted">\${(post.created_at || '').substring(0, 10)}</small>
                </div>
                <h6 class="mb-1 fw-bold">\${highlightMatch(post.title, query)}</h6>
                <p class="mb-0 text-muted small text-truncate">\${post.excerpt || ''}</p>
            \`;
            resultsList.appendChild(item);
        });

        dropdown.classList.remove('d-none');
    }

    // Đóng dropdown khi click ra ngoài
    document.addEventListener('click', (e) => {
        if (!searchInput.contains(e.target) && !dropdown.contains(e.target)) {
            dropdown.classList.add('d-none');
        }
    });

    // Mở lại dropdown nếu click vào input và có giá trị
    searchInput.addEventListener('focus', () => {
        if (searchInput.value.trim().length > 0 && resultsList.children.length > 0) {
            dropdown.classList.remove('d-none');
        }
    });
}

// 3. Helper chèn nhanh Markdown Toolbar
function insertMd(prefix, suffix, defaultText) {
    const editor = document.getElementById('markdown-editor');
    if (!editor) return;

    const start = editor.selectionStart;
    const end = editor.selectionEnd;
    const selected = editor.value.substring(start, end) || defaultText;

    const replacement = prefix + selected + suffix;
    editor.value = editor.value.substring(0, start) + replacement + editor.value.substring(end);
    editor.focus();
    editor.selectionStart = start + prefix.length;
    editor.selectionEnd = start + prefix.length + selected.length;

    // Kích hoạt event input để update preview
    editor.dispatchEvent(new Event('input'));
}

// 4. Live Markdown Preview đơn giản
function initMarkdownPreview() {
    const editor = document.getElementById('markdown-editor');
    const preview = document.getElementById('markdown-preview');
    if (!editor || !preview) return;

    editor.addEventListener('input', () => {
        const text = editor.value;
        if (!text.trim()) {
            preview.innerHTML = '<p class="text-muted small">Bản xem trước trực tiếp...</p>';
            return;
        }
        // Thay thế cơ bản cho preview client-side
        let html = escapeHtml(text)
            .replace(/^# (.*$)/gim, '<h3 class="fw-bold mt-2">$1</h3>')
            .replace(/^## (.*$)/gim, '<h4 class="fw-bold mt-2">$1</h4>')
            .replace(/^### (.*$)/gim, '<h5 class="fw-bold mt-2">$1</h5>')
            .replace(/\\*\\*(.*?)\\*\\*/gim, '<strong>$1</strong>')
            .replace(/\\*(.*?)\\*/gim, '<em>$1</em>')
            .replace(/^> (.*$)/gim, '<blockquote class="border-start border-3 border-primary ps-2 text-muted">$1</blockquote>')
            .replace(/\\n/gim, '<br>');
        preview.innerHTML = html;
    });
}

function escapeHtml(str) {
    return (str || '').replace(/[&<>"']/g, m => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
    })[m]);
}

function highlightMatch(text, query) {
    if (!query) return escapeHtml(text);
    const regex = new RegExp(\`(\${query.replace(/[-\\/\\\\^$*+?.()|[\\]{}]/g, '\\\\$&')})\`, 'gi');
    return escapeHtml(text).replace(regex, '<mark class="p-0 bg-warning-subtle">$1</mark>');
}
`
  },
  {
    name: 'requirements.txt',
    path: 'requirements.txt',
    language: 'text',
    description: 'Các thư viện Python cần thiết để chạy dự án Flask.',
    content: `Flask==3.0.3
markdown2==2.4.13
bleach==6.1.0
`
  },
  {
    name: 'README.md',
    path: 'README.md',
    language: 'markdown',
    description: 'Hướng dẫn cài đặt, cấu trúc thư mục và chạy ứng dụng Flask Blog.',
    content: `# Flask Blog Platform với SQLite & Markdown

Website đăng tải blog đầy đủ tính năng được xây dựng bằng framework **Python Flask**, cơ sở dữ liệu **SQLite**, giao diện **Bootstrap 5** hỗ trợ **Dark Mode** và tìm kiếm tức thì **Real-time Instant Search**.

---

## 📁 Cấu trúc thư mục dự án

\`\`\`text
flask_blog/
│
├── app.py                  # Server chính chứa toàn bộ routes & API search
├── database.py             # Kết nối & hàm khởi tạo SQLite
├── schema.sql              # Cấu trúc CSDL (posts, comments, indexes)
├── requirements.txt        # Danh sách thư viện Python
├── README.md               # Hướng dẫn sử dụng
│
├── templates/              # Giao diện Jinja2 HTML + Bootstrap 5
│   ├── base.html           # Layout chung, Dark Mode, Top Search bar
│   ├── index.html          # Danh sách bài viết thời gian thực
│   ├── post_detail.html    # Chi tiết bài viết Markdown & Bình luận
│   ├── create_post.html    # Form tạo bài viết với Markdown Editor
│   └── edit_post.html      # Form chỉnh sửa bài viết
│
└── static/                 # Tài nguyên tĩnh
    ├── css/
    │   └── style.css       # Tùy biến CSS, Dark Mode, Markdown styling
    └── js/
        └── app.js          # Live Search tức thì, Dark Mode LocalStorage
\`\`\`

---

## 🚀 Hướng dẫn cài đặt và chạy ứng dụng

### 1. Cài đặt các thư viện phụ thuộc:
\`\`\`bash
pip install -r requirements.txt
\`\`\`

### 2. Khởi chạy ứng dụng:
\`\`\`bash
python app.py
\`\`\`

Ứng dụng sẽ tự động khởi tạo cơ sở dữ liệu SQLite \`blog.db\` và mở server tại địa chỉ:
👉 **http://127.0.0.1:5000**

---

## ✨ Các tính năng chính
- 📝 **Đăng, sửa và xóa bài viết**: Quản lý bài viết linh hoạt và bảo mật.
- ⚡ **Tìm kiếm tức thì (Real-time Instant Search)**: Hiển thị kết quả ngay khi người dùng gõ phím tại thanh tìm kiếm trên cùng.
- 🎨 **Hỗ trợ Markdown toàn diện**: Soạn thảo với cú pháp tiêu đề, danh sách, khối mã, trích dẫn, bảng biểu.
- 🌙 **Chế độ Dark Mode**: Chuyển đổi sáng / tối mượt mà và tự động lưu vào \`localStorage\`.
- 📱 **Giao diện Bootstrap 5 Responsive**: Hiển thị tối ưu và chuyên nghiệp trên máy tính, máy tính bảng và điện thoại di động.
`
  },
  {
    name: 'Dockerfile',
    path: 'Dockerfile',
    language: 'dockerfile',
    description: 'Tệp cấu hình Dockerfile Multi-stage tối ưu hóa cho môi trường Linux Container & Cloud Run.',
    content: `# Multi-stage Build cho môi trường Linux
FROM node:22-alpine AS builder
WORKDIR /app
COPY package.json ./
RUN npm install --frozen-lockfile || npm install
COPY . .
ENV NODE_ENV=production
RUN npm run build

FROM node:22-alpine AS runner
WORKDIR /app
ENV NODE_ENV=production
ENV PORT=3000
ENV HOST=0.0.0.0
COPY package.json ./
RUN npm install --omit=dev --ignore-scripts && npm cache clean --force
COPY --from=builder /app/dist ./dist
COPY --from=builder /app/index.html ./index.html
USER node
EXPOSE 3000
HEALTHCHECK --interval=30s --timeout=5s --start-period=5s --retries=3 \\
  CMD wget --no-verbose --tries=1 --spider http://127.0.0.1:3000/api/health || exit 1
CMD ["node", "dist/server.cjs"]`
  },
  {
    name: 'docker-compose.yml',
    path: 'docker-compose.yml',
    language: 'yaml',
    description: 'Cấu hình Docker Compose để khởi chạy 1 lệnh trên Linux Server.',
    content: `services:
  flask-blog-app:
    build:
      context: .
      dockerfile: Dockerfile
    container_name: flask_blog_production
    restart: unless-stopped
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - PORT=3000
    deploy:
      resources:
        limits:
          cpus: '1.0'
          memory: 512M
        reservations:
          memory: 128M
    healthcheck:
      test: ["CMD", "wget", "--no-verbose", "--tries=1", "--spider", "http://localhost:3000/api/health"]
      interval: 30s
      timeout: 5s
      retries: 3
      start_period: 10s`
  },
  {
    name: 'nginx.conf',
    path: 'nginx.conf',
    language: 'nginx',
    description: 'Cấu hình Nginx Reverse Proxy tối ưu hóa Gzip, Caching 1 năm và bảo mật trên Linux VPS (Ubuntu/Debian).',
    content: `server {
    listen 80;
    server_name yourdomain.com;

    # Gzip Compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied any;
    gzip_types text/plain text/css text/xml application/javascript application/json image/svg+xml;

    # Security Headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /assets/ {
        proxy_pass http://127.0.0.1:3000/assets/;
        expires 1y;
        add_header Cache-Control "public, max-age=31536000, immutable";
    }

    location = /api/health {
        proxy_pass http://127.0.0.1:3000/api/health;
        access_log off;
    }
}`
  },
  {
    name: 'deploy.sh',
    path: 'deploy.sh',
    language: 'bash',
    description: 'Script Bash tự động triển khai và build sản phẩm trên máy chủ Linux.',
    content: `#!/usr/bin/env bash
set -e

echo "🐧 [1/5] Kiểm tra môi trường Node.js trên Linux..."
node -v
npm -v

echo "📦 [2/5] Cài đặt dependencies..."
npm install

echo "⚡ [3/5] Biên dịch Production Bundle..."
npm run build

echo "🚀 [4/5] Kiểm tra file phân phối dist/..."
ls -lh dist/

echo "✅ [5/5] Hoàn tất triển khai! Chạy: pm2 start ecosystem.config.cjs"
`
  },
  {
    name: 'gunicorn_config.py',
    path: 'gunicorn_config.py',
    language: 'python',
    description: 'Cấu hình Gunicorn WSGI Server chạy đa luồng cho Python Flask trên Linux.',
    content: `"""Cấu hình Gunicorn cho môi trường Linux Production"""
import multiprocessing

bind = "0.0.0.0:5000"
workers = multiprocessing.cpu_count() * 2 + 1
worker_class = "gthread"
threads = 2
timeout = 60
keepalive = 5
accesslog = "-"
errorlog = "-"
loglevel = "info"
`
  },
  {
    name: 'flask-blog.service',
    path: 'flask-blog.service',
    language: 'ini',
    description: 'Tệp cấu hình Systemd Service trên Linux để tự động khởi động cùng hệ điều hành.',
    content: `[Unit]
Description=Flask Blog Studio Production Service
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/var/www/flask-blog
ExecStart=/usr/bin/node /var/www/flask-blog/dist/server.cjs
Restart=always
RestartSec=5
Environment=NODE_ENV=production
Environment=PORT=3000

NoNewPrivileges=true
ProtectSystem=full
ProtectHome=true

[Install]
WantedBy=multi-user.target`
  }
];
