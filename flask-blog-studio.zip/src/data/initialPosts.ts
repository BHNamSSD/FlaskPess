import { Post } from '../types';

export const INITIAL_POSTS: Post[] = [
  {
    id: 'post-1',
    title: 'Xây dựng Blog hoàn chỉnh với Python Flask và SQLite',
    slug: 'xay-dung-blog-voi-python-flask-va-sqlite',
    excerpt: 'Hướng dẫn chi tiết từng bước xây dựng một ứng dụng web blog chuẩn RESTful với Flask framework, cơ sở dữ liệu SQLite, trình soạn thảo Markdown và giao diện Bootstrap 5 responsive.',
    content: `# Xây dựng Blog hoàn chỉnh với Python Flask và SQLite

Chào mừng bạn đến với hướng dẫn xây dựng nền tảng Blog cá nhân bằng **Python Flask** và **SQLite**! 

Trong bài viết này, chúng ta sẽ cùng nhau tìm hiểu cách thiết kế kiến trúc web tinh gọn, an toàn và dễ mở rộng.

---

## 1. Tổng quan kiến trúc hệ thống

Hệ thống được thiết kế theo mô hình MVC (Model - View - Controller) tiêu chuẩn:
- **Model**: Quản lý dữ liệu với SQLite thông qua module \`sqlite3\` an toàn.
- **View**: Template Jinja2 kết hợp Bootstrap 5 hỗ trợ Dark Mode tự động.
- **Controller**: Các Flask Route xử lý CRUD, tìm kiếm thời gian thực (Real-time Instant Search).

\`\`\`python
from flask import Flask, render_template, request, redirect, url_for, jsonify
import sqlite3
import markdown2

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-12345'
\`\`\`

---

## 2. Thiết kế Cơ sở dữ liệu SQLite

Bảng \`posts\` lưu trữ thông tin bài viết với định dạng Markdown gốc:

| Trường (Column) | Kiểu dữ liệu | Mô tả |
| :--- | :--- | :--- |
| \`id\` | INTEGER PRIMARY KEY | Khóa chính tự tăng |
| \`title\` | TEXT NOT NULL | Tiêu đề bài viết |
| \`content\` | TEXT NOT NULL | Nội dung định dạng Markdown |
| \`category\` | TEXT | Danh mục bài viết |
| \`created_at\` | TIMESTAMP | Thời gian tạo bài viết |

> **Mẹo bảo mật:** Luôn sử dụng Parameterized Query (\`?\`) trong SQLite để ngăn chặn triệt để lỗ hổng SQL Injection!

---

## 3. Tính năng Tìm kiếm tức thì (Live Search)

Khi người dùng nhập ký tự vào ô tìm kiếm ở thanh điều hướng, client gửi yêu cầu không đồng bộ (\`fetch\`) tới endpoint API:

\`\`\`javascript
const searchInput = document.getElementById('top-search-input');
searchInput.addEventListener('input', debounce(async (e) => {
  const query = e.target.value.trim();
  const res = await fetch(\`/api/search?q=\${encodeURIComponent(query)}\`);
  const data = await res.json();
  renderSearchResults(data);
}, 200));
\`\`\`

---

## 4. Kết luận

Với sự kết hợp giữa **Flask**, **SQLite**, **Markdown** và **Bootstrap**, bạn đã có một website blog nhanh nhẹn, tối ưu hóa cho cả thiết bị di động lẫn máy tính để bàn!`,
    category: 'Lập trình Python',
    tags: ['Flask', 'SQLite', 'Python', 'Bootstrap', 'Markdown'],
    coverImage: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=1200&q=80',
    author: {
      name: 'Nguyễn Văn Nam',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
      role: 'Backend Architect',
    },
    createdAt: '2026-08-23T14:30:00Z',
    updatedAt: '2026-08-24T01:15:00Z',
    readingTimeMinutes: 4,
    likes: 42,
    views: 320,
    isFeatured: true,
    comments: [
      {
        id: 'c-1',
        author: 'Trần Hoàng',
        content: 'Bài viết rất chi tiết và dễ hiểu! Cảm ơn tác giả đã chia sẻ kiến trúc chuẩn Flask.',
        createdAt: '2026-08-23T18:20:00Z',
        avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&q=80',
      },
      {
        id: 'c-2',
        author: 'Lê Thảo My',
        content: 'Tính năng Live Search qua API kết hợp Bootstrap 5 dùng rất mượt trên điện thoại.',
        createdAt: '2026-08-24T00:45:00Z',
        avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=100&q=80',
      }
    ],
  },
  {
    id: 'post-2',
    title: 'Nắm vững cú pháp Markdown cho người viết nội dung chuyên nghiệp',
    slug: 'nam-vung-cu-phap-markdown-chuyen-nghiep',
    excerpt: 'Tìm hiểu tất cả các mẹo định dạng từ cơ bản đến nâng cao trong Markdown: bảng biểu, khối mã lập trình, danh sách việc cần làm (Task lists) và trích dẫn.',
    content: `# Nắm vững cú pháp Markdown cho người viết nội dung chuyên nghiệp

Markdown là ngôn ngữ đánh dấu siêu nhẹ được tạo ra bởi John Gruber vào năm 2004. Với Markdown, bạn có thể tập trung hoàn toàn vào nội dung mà không bị phân tâm bởi các công cụ định dạng phức tạp.

## 1. Định dạng văn bản cơ bản

- **Chữ đậm (Bold)**: \`**nội dung đậm**\` -> **nội dung đậm**
- *Chữ nghiêng (Italic)*: \`*nội dung nghiêng*\` -> *nội dung nghiêng*
- ~~Chữ gạch ngang~~: \`~~gạch ngang~~\` -> ~~gạch ngang~~
- \`Code nội dòng\`: \`\` \`print("Hello World")\` \`\`

## 2. Danh sách & Danh sách công việc (Task lists)

### Danh sách công việc dự án:
- [x] Thiết kế cấu trúc cơ sở dữ liệu SQLite
- [x] Tạo trang tạo & chỉnh sửa bài viết Markdown
- [x] Cài đặt thanh tìm kiếm tức thì trên đầu trang
- [ ] Triển khai ứng dụng lên server sản xuất

## 3. Khối trích dẫn (Blockquote)

> "Đơn giản là đỉnh cao của sự tinh tế."
> — *Leonardo da Vinci*

## 4. Chèn hình ảnh và liên kết

![Lập trình viên làm việc](https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80)

Viết blog bằng Markdown giúp bạn dễ dàng lưu trữ trên Git, đồng bộ qua cơ sở dữ liệu và hiển thị đẹp mắt trên mọi thiết bị!`,
    category: 'Kỹ năng viết',
    tags: ['Markdown', 'Content', 'Writing', 'Tips'],
    coverImage: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?auto=format&fit=crop&w=1200&q=80',
    author: {
      name: 'Minh Hạnh',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=200&q=80',
      role: 'Content Lead',
    },
    createdAt: '2026-08-22T09:15:00Z',
    updatedAt: '2026-08-22T11:00:00Z',
    readingTimeMinutes: 3,
    likes: 28,
    views: 185,
    isFeatured: false,
    comments: [],
  },
  {
    id: 'post-3',
    title: 'Tối ưu hóa Dark Mode và LocalStorage cho trải nghiệm đọc ban đêm',
    slug: 'toi-uu-hoa-dark-mode-va-localstorage',
    excerpt: 'Làm thế nào để chuyển đổi giao diện sáng/tối mượt mà không bị chớp màn hình (FOUC), đồng thời lưu trữ tùy chọn người dùng vĩnh viễn trên trình duyệt.',
    content: `# Tối ưu hóa Dark Mode và LocalStorage cho trải nghiệm đọc ban đêm

Chế độ tối (Dark Mode) không chỉ giúp tiết kiệm pin trên màn hình OLED mà còn giảm đáng kể tình trạng mỏi mắt khi đọc bài viết vào ban đêm.

## 1. Lưu trữ trạng thái với LocalStorage

Để lưu lại tùy chọn của người dùng ngay cả khi họ tải lại trang hoặc quay lại vào ngày hôm sau:

\`\`\`javascript
// Đọc trạng thái từ localStorage
function getInitialTheme() {
  const savedTheme = localStorage.getItem('blog_theme');
  if (savedTheme) {
    return savedTheme;
  }
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

// Chuyển đổi và lưu trữ
function toggleTheme() {
  const current = document.documentElement.classList.contains('dark') ? 'dark' : 'light';
  const next = current === 'dark' ? 'light' : 'dark';
  
  document.documentElement.classList.toggle('dark', next === 'dark');
  localStorage.setItem('blog_theme', next);
}
\`\`\`

## 2. Thiết kế bảng màu tương phản chuẩn WCAG AA

Khi thiết kế giao diện tối, tránh sử dụng màu đen thuần túy (\`#000000\`). Thay vào đó:
1. **Nền chính**: Xám than trầm (\`#0f172a\` hoặc \`#111827\`)
2. **Nền thẻ (Cards)**: \`#1e293b\`
3. **Màu chữ chính**: \`#f8fafc\` để đảm bảo độ tương phản cao
4. **Màu chữ phụ**: \`#94a3b8\`

Nhờ đó, người đọc có cảm giác êm dịu, không bị chói mắt!`,
    category: 'Giao diện & UI/UX',
    tags: ['DarkMode', 'UI/UX', 'LocalStorage', 'CSS', 'JavaScript'],
    coverImage: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=1200&q=80',
    author: {
      name: 'Đức Anh',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80',
      role: 'Frontend Engineer',
    },
    createdAt: '2026-08-21T16:40:00Z',
    updatedAt: '2026-08-21T17:00:00Z',
    readingTimeMinutes: 3,
    likes: 35,
    views: 240,
    isFeatured: false,
    comments: [
      {
        id: 'c-3',
        author: 'Ngọc Mai',
        content: 'Chế độ tối kết hợp phông chữ to rõ ràng giúp đọc bài buổi tối rất thích!',
        createdAt: '2026-08-22T08:10:00Z',
        avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80',
      }
    ],
  }
];

export const AVAILABLE_CATEGORIES = [
  'Tất cả',
  'Lập trình Python',
  'Kỹ năng viết',
  'Giao diện & UI/UX',
  'Cơ sở dữ liệu',
  'Mẹo & Thủ thuật',
];
