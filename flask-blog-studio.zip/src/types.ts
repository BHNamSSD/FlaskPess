export type UserRole = 'admin' | 'user';

export type UserStatus = 'active' | 'banned';

export interface User {
  id: string;
  username: string;
  name: string;
  email: string;
  password?: string;
  avatar: string;
  role: UserRole;
  bio?: string;
  status: UserStatus;
  createdAt: string;
  lastLoginAt?: string;
  postsCount?: number;
  isAdminVerified?: boolean;
}

export interface Comment {
  id: string;
  author: string;
  authorId?: string;
  authorUsername?: string;
  authorRole?: UserRole;
  content: string;
  createdAt: string;
  avatarUrl?: string;
}

export interface Post {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  category: string;
  tags: string[];
  coverImage?: string;
  author: {
    id?: string;
    name: string;
    avatar: string;
    role: string;
  };
  createdAt: string;
  updatedAt: string;
  readingTimeMinutes: number;
  likes: number;
  views: number;
  comments: Comment[];
  isFeatured?: boolean;
}

export type ViewMode = 'grid' | 'list' | 'compact';

export type CurrentView = 'home' | 'post-detail' | 'create' | 'edit' | 'flask-code' | 'users-management';

export interface FlaskProjectFile {
  name: string;
  path: string;
  language: 'python' | 'html' | 'css' | 'javascript' | 'sql' | 'text' | 'markdown' | 'dockerfile' | 'yaml' | 'nginx' | 'bash' | 'ini';
  description: string;
  content: string;
}

