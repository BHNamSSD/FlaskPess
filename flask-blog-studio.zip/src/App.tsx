import React, { useState, useEffect } from 'react';
import { Post, Comment, CurrentView, User } from './types';
import { 
  getStoredPosts, 
  saveStoredPosts, 
  getStoredTheme, 
  saveStoredTheme,
  getStoredUsers,
  saveStoredUsers,
  getStoredCurrentUser,
  saveStoredCurrentUser
} from './utils/storage';
import { Navbar } from './components/Navbar';
import { PostList } from './components/PostList';
import { PostDetail } from './components/PostDetail';
import { MarkdownEditor } from './components/MarkdownEditor';
import { FlaskCodeViewer } from './components/FlaskCodeViewer';
import { UserManagement } from './components/UserManagement';
import { AuthModal } from './components/AuthModal';
import { DeleteConfirmModal } from './components/DeleteConfirmModal';
import { Toast, ToastMessage } from './components/Toast';

export default function App() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [currentView, setCurrentView] = useState<CurrentView>('home');
  const [activePostId, setActivePostId] = useState<string | null>(null);
  
  // User Authentication & Roles (Admin vs User)
  const [users, setUsers] = useState<User[]>([]);
  const [currentUser, setCurrentUser] = useState<User>({
    id: 'user-admin-1',
    name: 'BHNam',
    username: 'admin',
    email: 'phamhuynam.com@gmail.com',
    role: 'admin',
    status: 'active',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    createdAt: new Date().toISOString(),
    bio: 'Quản trị viên hệ thống & Nhà phát triển chính FlaskPress SQLite',
    postsCount: 5,
    isAdminVerified: true,
  });

  // Auth & Account Modal State
  const [authModalState, setAuthModalState] = useState<{
    isOpen: boolean;
    tab: 'login' | 'register' | 'switch' | 'verify-admin';
  }>({
    isOpen: false,
    tab: 'login',
  });

  // Search and Filter States
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('Tất cả');
  const [selectedTag, setSelectedTag] = useState<string>('');

  // Modals & Toasts
  const [deleteModalState, setDeleteModalState] = useState<{ isOpen: boolean; postId: string | null; postTitle: string }>({
    isOpen: false,
    postId: null,
    postTitle: '',
  });
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Initialize data, users, and theme on first load
  useEffect(() => {
    const loadedPosts = getStoredPosts();
    setPosts(loadedPosts);

    const loadedUsers = getStoredUsers();
    setUsers(loadedUsers);

    const storedCurrent = getStoredCurrentUser();
    if (storedCurrent) {
      setCurrentUser(storedCurrent);
    }

    const initialTheme = getStoredTheme();
    setTheme(initialTheme);
    saveStoredTheme(initialTheme);
  }, []);

  const addToast = (text: string, type: 'success' | 'error' | 'info' = 'success') => {
    const newToast: ToastMessage = {
      id: `${Date.now()}-${Math.random()}`,
      text,
      type,
    };
    setToasts((prev) => [...prev, newToast]);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const handleToggleTheme = () => {
    const nextTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(nextTheme);
    saveStoredTheme(nextTheme);
    addToast(nextTheme === 'dark' ? 'Đã bật chế độ giao diện Tối' : 'Đã bật chế độ giao diện Sáng', 'info');
  };

  const handleNavigate = (view: CurrentView, postId?: string) => {
    // RBAC Security Check: only Admin can access users-management
    if (view === 'users-management' && currentUser.role !== 'admin') {
      addToast('Bạn không có quyền truy cập trang Quản lý người dùng! Vui lòng đăng nhập tài khoản Admin hoặc xem cơ chế xác minh.', 'error');
      setAuthModalState({ isOpen: true, tab: 'verify-admin' });
      return;
    }

    setCurrentView(view);
    if (postId) {
      setActivePostId(postId);
      // Increment views count when opening detail
      if (view === 'post-detail') {
        setPosts((prev) => {
          const updated = prev.map((p) => (p.id === postId ? { ...p, views: p.views + 1 } : p));
          saveStoredPosts(updated);
          return updated;
        });
      }
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // User Management Handlers
  const handleUpdateUsers = (updatedUsers: User[]) => {
    setUsers(updatedUsers);
    saveStoredUsers(updatedUsers);

    // If current user was updated, sync currentUser state
    const currentFound = updatedUsers.find((u) => u.id === currentUser.id);
    if (currentFound) {
      setCurrentUser(currentFound);
      saveStoredCurrentUser(currentFound);
    }
  };

  const handleLogin = (user: User) => {
    const updatedUser: User = {
      ...user,
      lastLoginAt: new Date().toISOString(),
    };
    setCurrentUser(updatedUser);
    saveStoredCurrentUser(updatedUser);

    // Update in users array
    const updatedUsers = users.map((u) => (u.id === user.id ? updatedUser : u));
    setUsers(updatedUsers);
    saveStoredUsers(updatedUsers);

    if (updatedUser.role !== 'admin' && currentView === 'users-management') {
      setCurrentView('home');
    }
  };

  const handleRegister = (newUserData: Omit<User, 'id' | 'createdAt' | 'lastLoginAt'>) => {
    const newUser: User = {
      ...newUserData,
      id: `user-${Date.now()}`,
      createdAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
      postsCount: 0,
    };

    const updatedUsers = [...users, newUser];
    setUsers(updatedUsers);
    saveStoredUsers(updatedUsers);

    setCurrentUser(newUser);
    saveStoredCurrentUser(newUser);
  };

  // CRUD Operations
  const handleCreatePost = (newPostData: Partial<Post>) => {
    const newPost: Post = {
      id: `post-${Date.now()}`,
      title: newPostData.title || 'Bài viết không có tiêu đề',
      slug: newPostData.slug || `post-${Date.now()}`,
      excerpt: newPostData.excerpt || '',
      content: newPostData.content || '',
      category: newPostData.category || 'Chung',
      tags: newPostData.tags || [],
      coverImage: newPostData.coverImage,
      author: newPostData.author || {
        name: currentUser.name,
        avatar: currentUser.avatar,
        role: currentUser.role === 'admin' ? 'Quản trị viên' : 'Tác giả',
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      readingTimeMinutes: newPostData.readingTimeMinutes || 2,
      likes: 0,
      views: 1,
      comments: [],
    };

    const updated = [newPost, ...posts];
    setPosts(updated);
    saveStoredPosts(updated);

    // Update user post count
    const updatedUsers = users.map((u) => (u.id === currentUser.id ? { ...u, postCount: u.postCount + 1 } : u));
    handleUpdateUsers(updatedUsers);

    addToast('Đăng bài viết mới thành công!', 'success');
    handleNavigate('post-detail', newPost.id);
  };

  const handleEditPost = (updatedData: Partial<Post>) => {
    if (!activePostId) return;

    const updated = posts.map((p) => {
      if (p.id === activePostId) {
        return {
          ...p,
          ...updatedData,
          updatedAt: new Date().toISOString(),
        };
      }
      return p;
    });

    setPosts(updated);
    saveStoredPosts(updated);
    addToast('Cập nhật bài viết thành công!', 'success');
    handleNavigate('post-detail', activePostId);
  };

  const handlePromptDelete = (postId: string) => {
    const target = posts.find((p) => p.id === postId);
    if (!target) return;
    setDeleteModalState({
      isOpen: true,
      postId: target.id,
      postTitle: target.title,
    });
  };

  const handleConfirmDelete = () => {
    if (!deleteModalState.postId) return;

    const updated = posts.filter((p) => p.id !== deleteModalState.postId);
    setPosts(updated);
    saveStoredPosts(updated);
    setDeleteModalState({ isOpen: false, postId: null, postTitle: '' });
    addToast('Đã xóa bài viết khỏi cơ sở dữ liệu!', 'info');

    if (currentView === 'post-detail' || currentView === 'edit') {
      setCurrentView('home');
    }
  };

  const handleLikePost = (postId: string) => {
    const updated = posts.map((p) => (p.id === postId ? { ...p, likes: p.likes + 1 } : p));
    setPosts(updated);
    saveStoredPosts(updated);
  };

  const handleAddComment = (postId: string, commentData: Omit<Comment, 'id' | 'createdAt'>) => {
    const newComment: Comment = {
      id: `comment-${Date.now()}`,
      author: commentData.author || currentUser.name,
      authorId: commentData.authorId || currentUser.id,
      authorUsername: commentData.authorUsername || currentUser.username,
      authorRole: commentData.authorRole || currentUser.role,
      content: commentData.content,
      avatarUrl: commentData.avatarUrl || currentUser.avatar,
      createdAt: new Date().toISOString(),
    };

    const updated = posts.map((p) => {
      if (p.id === postId) {
        return {
          ...p,
          comments: [newComment, ...(p.comments || [])],
        };
      }
      return p;
    });

    setPosts(updated);
    saveStoredPosts(updated);
  };

  const handleDeleteComment = (postId: string, commentId: string) => {
    const updated = posts.map((p) => {
      if (p.id === postId) {
        return {
          ...p,
          comments: p.comments.filter((c) => c.id !== commentId),
        };
      }
      return p;
    });

    setPosts(updated);
    saveStoredPosts(updated);
    addToast('Đã xóa bình luận!', 'info');
  };

  const activePost = posts.find((p) => p.id === activePostId) || posts[0];

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 font-sans transition-colors duration-200">
      
      {/* Navigation Bar */}
      <Navbar
        currentView={currentView}
        onNavigate={handleNavigate}
        theme={theme}
        onToggleTheme={handleToggleTheme}
        posts={posts}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        selectedCategory={selectedCategory}
        onSelectCategory={(cat) => {
          setSelectedCategory(cat);
          if (currentView !== 'home') setCurrentView('home');
        }}
        currentUser={currentUser}
        onOpenAuth={(tab) => setAuthModalState({ isOpen: true, tab: tab || 'login' })}
      />

      {/* Main View Router */}
      <main className="flex-1">
        {currentView === 'home' && (
          <PostList
            posts={posts}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            selectedCategory={selectedCategory}
            onSelectCategory={setSelectedCategory}
            selectedTag={selectedTag}
            onSelectTag={setSelectedTag}
            onNavigate={handleNavigate}
            onDeletePost={handlePromptDelete}
            onLikePost={handleLikePost}
            currentUser={currentUser}
          />
        )}

        {currentView === 'post-detail' && activePost && (
          <PostDetail
            post={activePost}
            onNavigate={handleNavigate}
            onEdit={(id) => handleNavigate('edit', id)}
            onDelete={handlePromptDelete}
            onLike={handleLikePost}
            onAddComment={handleAddComment}
            onDeleteComment={handleDeleteComment}
            showToast={addToast}
            currentUser={currentUser}
          />
        )}

        {currentView === 'create' && (
          <MarkdownEditor
            onSave={handleCreatePost}
            onCancel={() => handleNavigate('home')}
            showToast={addToast}
          />
        )}

        {currentView === 'edit' && activePost && (
          <MarkdownEditor
            postToEdit={activePost}
            onSave={handleEditPost}
            onCancel={() => handleNavigate('post-detail', activePost.id)}
            showToast={addToast}
          />
        )}

        {currentView === 'flask-code' && (
          <FlaskCodeViewer
            onBack={() => handleNavigate('home')}
            showToast={addToast}
          />
        )}

        {currentView === 'users-management' && (
          <UserManagement
            users={users}
            currentUser={currentUser}
            posts={posts}
            onUpdateUsers={handleUpdateUsers}
            onNavigate={handleNavigate}
            showToast={addToast}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-bold text-xs">
              F
            </div>
            <span className="font-semibold text-slate-700 dark:text-slate-300">Flask Blog Platform</span>
            <span>• Chuẩn kiến trúc Python Flask & SQLite • Phân quyền RBAC</span>
          </div>

          <div className="flex items-center gap-4">
            {currentUser.role === 'admin' && (
              <button
                onClick={() => handleNavigate('users-management')}
                className="hover:text-amber-500 font-semibold"
              >
                Quản lý người dùng
              </button>
            )}
            <button
              onClick={() => handleNavigate('flask-code')}
              className="hover:text-indigo-600 dark:hover:text-indigo-400 underline underline-offset-4"
            >
              Mã nguồn Python Flask
            </button>
            <span>•</span>
            <button
              onClick={() => setAuthModalState({ isOpen: true, tab: 'verify-admin' })}
              className="hover:text-amber-500 font-semibold flex items-center gap-1"
            >
              👑 Cơ chế Admin
            </button>
            <span>•</span>
            <button
              onClick={() => setAuthModalState({ isOpen: true, tab: 'switch' })}
              className="hover:text-indigo-600 dark:hover:text-indigo-400"
            >
              Đổi tài khoản ({currentUser.name})
            </button>
          </div>
        </div>
      </footer>

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={deleteModalState.isOpen}
        title={deleteModalState.postTitle}
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteModalState({ isOpen: false, postId: null, postTitle: '' })}
      />

      {/* Authentication & User Roles Modal */}
      <AuthModal
        isOpen={authModalState.isOpen}
        initialTab={authModalState.tab}
        onClose={() => setAuthModalState((prev) => ({ ...prev, isOpen: false }))}
        users={users}
        currentUser={currentUser}
        onLogin={handleLogin}
        onRegister={handleRegister}
        showToast={addToast}
      />

      {/* Global Notification Toasts */}
      <Toast toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}

