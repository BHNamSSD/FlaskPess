// PM2 Process Manager Configuration for Linux Environments
module.exports = {
  apps: [
    {
      name: 'flask-blog-studio',
      script: 'dist/server.cjs',
      instances: 'max', // Multi-core clustering on Linux
      exec_mode: 'cluster',
      autorestart: true,
      watch: false,
      max_memory_restart: '500M',
      env_production: {
        NODE_ENV: 'production',
        PORT: 3000,
      },
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      error_file: './logs/error.log',
      out_file: './logs/out.log',
      merge_logs: true,
    },
  ],
};
