#!/usr/bin/env bash
# ==============================================================================
# Flask Blog Studio - Automated Linux Deployment & Healthcheck Script
# Compatible with Ubuntu 20.04/22.04/24.04, Debian 11/12, CentOS 8/9, Alpine
# ==============================================================================

set -e

echo "🐧 [1/5] Checking Linux Environment and Node.js..."
node -v || { echo "❌ Error: Node.js is not installed. Please install Node.js 18+"; exit 1; }
npm -v || { echo "❌ Error: npm is not installed."; exit 1; }

echo "📦 [2/5] Installing Dependencies..."
npm install --frozen-lockfile || npm install

echo "⚡ [3/5] Compiling Production Build with Bundler..."
npm run build

echo "📁 [4/5] Verifying Dist Output & Server Executable..."
if [ ! -f "dist/server.cjs" ] || [ ! -f "dist/index.html" ]; then
  echo "❌ Error: Production build missing dist/server.cjs or dist/index.html!"
  exit 1
fi

echo "🚀 [5/5] Deployment Successful!"
echo "---------------------------------------------------------------"
echo "To run with PM2 (Recommended on Linux VPS):"
echo "   npm install -g pm2"
echo "   pm2 start ecosystem.config.cjs --env production"
echo "   pm2 save && pm2 startup"
echo ""
echo "To run with Docker:"
echo "   docker-compose up -d --build"
echo ""
echo "To run directly with Node:"
echo "   NODE_ENV=production npm start"
echo "---------------------------------------------------------------"
