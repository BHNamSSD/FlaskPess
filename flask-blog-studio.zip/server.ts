import express from 'express';
import path from 'path';
import fs from 'fs';

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const HOST = '0.0.0.0';

// Linux & Container Health Check API (Docker, Kubernetes, Cloud Run, Nginx)
app.get('/api/health', (req, res) => {
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.status(200).json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptimeSeconds: Math.floor(process.uptime()),
    memoryUsageMB: {
      rss: Math.round(process.memoryUsage().rss / 1024 / 1024),
      heapTotal: Math.round(process.memoryUsage().heapTotal / 1024 / 1024),
      heapUsed: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
    },
    nodeVersion: process.version,
    platform: process.platform,
    arch: process.arch,
  });
});

// System Environment & Deployment Metadata (Sanitized)
app.get('/api/system-info', (req, res) => {
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.status(200).json({
    appName: 'Flask Blog Studio',
    version: '1.0.0',
    environment: process.env.NODE_ENV || 'production',
    os: `${process.platform} (${process.arch})`,
    node: process.version,
    serverTime: new Date().toISOString(),
  });
});

// Static assets serving with optimized HTTP caching for Linux Web Servers
const distPath = path.join(process.cwd(), 'dist');

if (fs.existsSync(distPath)) {
  // Static assets with immutable long-term caching (1 year)
  app.use(
    '/assets',
    express.static(path.join(distPath, 'assets'), {
      maxAge: '1y',
      immutable: true,
      index: false,
    })
  );

  // Other static files (favicon, manifest, robots, etc.) with 1 hour cache
  app.use(
    express.static(distPath, {
      maxAge: '1h',
      index: false,
    })
  );

  // SPA Fallback: Serve index.html for all non-file routes with no-cache header
  app.get('*', (req, res) => {
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.sendFile(path.join(distPath, 'index.html'));
  });
} else {
  // Development fallback when dist folder is not yet built
  app.get('*', (req, res) => {
    res.send(`
      <!DOCTYPE html>
      <html>
        <head><title>Flask Blog Studio - Initializing</title></head>
        <body style="font-family: sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; background: #0f172a; color: #f8fafc;">
          <div style="text-align: center; max-width: 500px; padding: 2rem; background: #1e293b; border-radius: 1rem; border: 1px solid #334155;">
            <h2 style="color: #6366f1;">Flask Blog Studio is Ready for Linux</h2>
            <p style="color: #94a3b8; font-size: 14px;">Build in progress. Run <code>npm run build</code> to compile static assets into <code>dist/</code>.</p>
          </div>
        </body>
      </html>
    `);
  });
}

// Start Server
const server = app.listen(PORT, HOST, () => {
  console.log(`=============================================`);
  console.log(`🚀 Flask Blog Studio Production Server Ready!`);
  console.log(`🌐 Local & Network: http://${HOST}:${PORT}`);
  console.log(`🐧 Target OS: Linux / Docker / Cloud Run`);
  console.log(`⏱️ Node Version: ${process.version}`);
  console.log(`=============================================`);
});

// Linux Signal Handling for Graceful Shutdown (Docker & systemd standard)
const gracefulShutdown = (signal: string) => {
  console.log(`\n[Linux Process] Received ${signal}. Starting graceful shutdown...`);
  server.close(() => {
    console.log('[Linux Process] HTTP server closed cleanly. Exiting.');
    process.exit(0);
  });

  // Force exit after 10s if connections linger
  setTimeout(() => {
    console.error('[Linux Process] Forceful shutdown timeout exceeded. Exiting immediately.');
    process.exit(1);
  }, 10000).unref();
};

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

export default app;
